#ifndef CLASS_IMPICCATO_H
#define CLASS_IMPICCATO_H

#include <vector>
#include <string>

#define MAXNOMETOPTEN 31
#define MAXTENTATIVI 8

class Impiccato
{
private:
	vector<string> parole;	// contiene le parole lette da un dizionario (file di testo)
	vector<string> topten;	// contiene le coppie (punti,nome) dei migliori giocatori
	vector<char> scelte;	// contiene l'elenco delle lettere scelte dal giocatore
	string parola;		// parola da indovinare
	string maschera;	// parola incompleta
	bool fineGioco;
	int tentativi;	
	int punti;
	int puntiTotali;
	int paroleIndovinate;	// n.ro di parole indovinate
	int letterePresenti;	// n.ro di lettere presenti
	char nomeDizionario[51];	// nome del file di testo del dizionario
public:
	Impiccato();
	bool CaricaDizionario(const char nomefile[]);
	bool SalvaDizionario();
	bool CaricaTopTen();
	void AccodaNomeNellaTopTen(char nome[],int punti);
	string GetMaschera();
	string GetParola();
	vector<char> GetScelte();
	vector<string> GetTopTen(); // restituisce la topten (elenco di punti/nome)
	void GeneraNuovaParola();
	void GeneraNuovaParola(string parola);

	int GetLunghezzaParola();
	int GetTentativi();
	int GetPunti();
	int GetPuntiTotali();
	int GetParoleIndovinate();

	bool IsGiocoFallito();
	bool IsParolaIndovinata();
	bool IsLetteraPresenteInParola(char c);
};
#endif

