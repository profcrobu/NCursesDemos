#include <vector>
#include <string>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

using namespace std;

#include "Impiccato.hpp"

Impiccato::Impiccato()
{
  parole.clear();
  topten.clear();
  scelte.clear();
  fineGioco = false;
  parola = "";
  maschera = "";
  tentativi = 0;
  punti = 0;
  puntiTotali = 0;
  paroleIndovinate = 0;
  strcpy(nomeDizionario,"");
  srand(time(0));
}

bool Impiccato::CaricaDizionario(const char nomefile[])
{
  FILE *f;
  char dato[50];
  int i;

  strcpy(nomeDizionario,nomefile);
  if ((f = fopen(nomeDizionario,"rt")) != NULL)
  {
    while (fscanf(f,"%s",dato) == 1)
    {
      for (i=0;i<strlen(dato);i++)
        dato[i] = toupper(dato[i]);
      parola = string(dato);
      parole.push_back(parola);
    }
    fclose(f);
    return(true);
  }
  else
    return(false);
}

bool Impiccato::SalvaDizionario()
{
  FILE *f;
  int i;

  if ((f = fopen(nomeDizionario,"wt")) != NULL)
  {
    for (i=0;i<parole.size();i++)
      fprintf(f,"%s\n",parole[i].c_str());
    fclose(f);
    return(true);
  }
  else
    return(false);
}

bool Impiccato::CaricaTopTen()
{
  FILE *f;
  char dato[81],nome[81];
  string parola;
  int i,n,punti;

  if ((f = fopen("topten.txt","rt")) != NULL)
  {
    topten.clear();
    while (feof(f) == false)
    {
      if (fscanf(f,"%d %s",&punti,nome) == 2)
      {
        sprintf(dato,"%05d %s",punti,nome);
        parola = dato;
        topten.push_back(parola);
      }
    }
    fclose(f);
    sort(topten.begin(),topten.end());
    reverse(topten.begin(),topten.end());
/*
    n = topten.size();
    if (n > 10)
      n = 10;
    ScriveYX(4,20," # Punti Nome");
    for (i=0;i<n;i++)
      ScriveYX(5+i,20,"%2d %s",i+1,topten[i].c_str());
    TracciaRettangolo(3,19,15,60);
    ScriveYX(3,37,"TOP TEN");
*/
    return(true);
  }
  else
    return(false);
}

void Impiccato::AccodaNomeNellaTopTen(char nome[],int punti)
{
  FILE *f;
  int i,n;
  string riga;
  char linea[81];

  if ((f = fopen("topten.txt","wt")) != NULL)
  {
    sprintf(linea,"%05d %s",punti,nome);
    riga = linea;
    topten.push_back(riga);
    sort(topten.begin(),topten.end());
    reverse(topten.begin(),topten.end());
    n = topten.size();
    if (n > 10)
      n = 10;
    for (i=0;i<n;i++)
    {
      fprintf(f,"%s\n",topten[i].c_str());
//      fprintf(stderr,"AccodaNomeNellaTopTen: topten[%d]=%s\n",i,topten[i].c_str());
    }
    fclose(f);
  }
}

vector<string> Impiccato::GetTopTen()
{
  return(topten);
}

string Impiccato::GetMaschera()
{
  return(maschera);
}

string Impiccato::GetParola()
{
  return(parola);
}

vector<char> Impiccato::GetScelte()
{
  return(scelte);
}


void Impiccato::GeneraNuovaParola(string Parola)
{
  int i;

  parola = Parola;
  maschera = Parola;
  tentativi = 0;
  punti = 0;
  for (i=0;i<maschera.length();i++)
    maschera[i] = '_';
}

void Impiccato::GeneraNuovaParola()
{
  int i;

  do
  {
    parola = parole[rand()%parole.size()];
  }
  while (parola.size() < 4 || parola.size() > 20);
  GeneraNuovaParola(parola);
}

int Impiccato::GetLunghezzaParola()
{
  return(parola.length());
}

int Impiccato::GetTentativi()
{
  return(tentativi);
}

int Impiccato::GetPunti()
{
  return(punti);
}

int Impiccato::GetPuntiTotali()
{
  return(puntiTotali);
}

int Impiccato::GetParoleIndovinate()
{
  return(paroleIndovinate);
}

bool Impiccato::IsParolaIndovinata()
{
  return(parola == maschera);
}

bool Impiccato::IsGiocoFallito()
{
  return(fineGioco = (tentativi >= MAXTENTATIVI));
}

bool Impiccato::IsLetteraPresenteInParola(char c)
{
  int i;

  c = toupper(c);
  if (c >= 'A' && c <= 'Z')
  {
    letterePresenti = 0;
    for (i=0;i<parola.size();i++)
      if (c == parola[i])
      {
        maschera[i] = parola[i];
        letterePresenti++;
      }
    if (letterePresenti == 0 && count(scelte.begin(),scelte.end(),c) == 0)
    {
      tentativi++;
      scelte.push_back(c);
    }
    fineGioco = (parola == maschera);
    if (fineGioco)
    {
      paroleIndovinate++;
      punti = 1000-tentativi*100;
      puntiTotali += punti;
      scelte.clear();
    }
    if (letterePresenti) 
      return(true);
  }
  return(false);
}
