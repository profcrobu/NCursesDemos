#include <vector>
#include <string>
#include <algorithm>
//#include <stdlib.h>

using namespace std;

#include "accessoNCurses5.h"
#include "Impiccato.hpp"

#define MAXPAROLEINDOVINATE 10

Impiccato impiccato;
char nome[MAXNOMETOPTEN+1];
int paroleIndovinate;

void VisualizzaTopTen()
{
  int i,n;
  vector<string> topten;

  impiccato.CaricaTopTen();
  topten = impiccato.GetTopTen();
  if (topten.size() > 0)
  {
    n = topten.size();
    if (n > 10)
      n = 10;
    ScriveYX(4,20," # Punti Nome");
    for (i=0;i<n;i++)
      ScriveYX(5+i,20,"%2d %s",i+1,topten[i].c_str());
    TracciaRettangolo(3,19,15,60);
    ScriveYX(3,37,"TOP TEN");
  }
}

void VisualizzaForca(int tentativi)
{
  ImpostaColoreTesto(COLOR_RED);
  AttivaGrassetto();
  if (tentativi >= 1)
  {
    ScriveCarattereYX(4,41,4194412);
    ScriveCarattereYX(4,42,4194417);
    ScriveCarattereYX(4,43,4194417);
    ScriveCarattereYX(4,44,4194417);
    ScriveCarattereYX(4,45,4194417);
    ScriveCarattereYX(4,46,4194417);
    ScriveCarattereYX(4,47,4194417);
    ScriveCarattereYX(4,48,4194417);
    ScriveCarattereYX(4,49,4194417);
    ScriveCarattereYX(4,50,4194417);
    ScriveCarattereYX(4,51,4194417);
    ScriveCarattereYX(4,52,4194417);
    ScriveCarattereYX(4,53,4194417);
    ScriveCarattereYX(4,54,4194417);
    ScriveCarattereYX(4,55,4194417);
    ScriveCarattereYX(4,56,4194417);
    ScriveCarattereYX(4,57,4194417);
    ScriveCarattereYX(4,58,4194417);
    ScriveCarattereYX(4,59,4194417);
    ScriveCarattereYX(4,60,4194417);
    ScriveCarattereYX(4,61,4194411);
    ScriveCarattereYX(5,41,4194424);
    ScriveCarattereYX(5,43,4194412);
    ScriveCarattereYX(5,44,4194417);
    ScriveCarattereYX(5,45,4194417);
    ScriveCarattereYX(5,46,4194417);
    ScriveCarattereYX(5,47,4194417);
    ScriveCarattereYX(5,48,4194417);
    ScriveCarattereYX(5,49,4194417);
    ScriveCarattereYX(5,50,4194417);
    ScriveCarattereYX(5,51,4194417);
    ScriveCarattereYX(5,52,4194417);
    ScriveCarattereYX(5,53,4194417);
    ScriveCarattereYX(5,54,4194417);
    ScriveCarattereYX(5,55,4194417);
    ScriveCarattereYX(5,56,4194417);
    ScriveCarattereYX(5,57,4194417);
    ScriveCarattereYX(5,58,4194417);
    ScriveCarattereYX(5,59,4194424);
    ScriveCarattereYX(5,59,4194417);
    ScriveCarattereYX(5,60,4194417);
    ScriveCarattereYX(5,61,4194410);
    ScriveCarattereYX(5,61,4194424);
    ScriveCarattereYX(5,61,4194410);
    ScriveCarattereYX(6,41,4194424);
    ScriveCarattereYX(6,43,4194424);
    ScriveCarattereYX(7,41,4194424);
    ScriveCarattereYX(7,43,4194424);
    ScriveCarattereYX(8,41,4194424);
    ScriveCarattereYX(8,43,4194424);
    ScriveCarattereYX(9,41,4194424);
    ScriveCarattereYX(9,43,4194424);
    ScriveCarattereYX(10,41,4194424);
    ScriveCarattereYX(10,43,4194424);
    ScriveCarattereYX(11,41,4194424);
    ScriveCarattereYX(11,43,4194424);
    ScriveCarattereYX(12,41,4194424);
    ScriveCarattereYX(12,43,4194424);
    ScriveCarattereYX(13,41,4194424);
    ScriveCarattereYX(13,43,4194424);
    ScriveCarattereYX(14,41,4194424);
    ScriveCarattereYX(14,43,4194424);
    ScriveCarattereYX(15,41,4194424);
    ScriveCarattereYX(15,43,4194424);
    ScriveCarattereYX(16,41,4194424);
    ScriveCarattereYX(16,43,4194424);
    ScriveCarattereYX(17,41,4194424);
    ScriveCarattereYX(17,43,4194424);
    ScriveCarattereYX(18,41,4194424);
    ScriveCarattereYX(18,43,4194424);
    ScriveCarattereYX(19,41,4194424);
    ScriveCarattereYX(19,43,4194424);
    ScriveCarattereYX(20,41,4194424);
    ScriveCarattereYX(20,43,4194424);
    ScriveCarattereYX(21,38,4194412);
    ScriveCarattereYX(21,39,4194417);
    ScriveCarattereYX(21,40,4194417);
    ScriveCarattereYX(21,41,4194410);
    ScriveCarattereYX(21,43,4194413);
    ScriveCarattereYX(21,44,4194417);
    ScriveCarattereYX(21,45,4194417);
    ScriveCarattereYX(21,46,4194411);
    ScriveCarattereYX(22,38,4194424);
    ScriveCarattereYX(22,46,4194424);
    ScriveCarattereYX(23,38,4194424);
    ScriveCarattereYX(23,38,4194413);
    ScriveCarattereYX(23,39,4194417);
    ScriveCarattereYX(23,40,4194417);
    ScriveCarattereYX(23,41,4194417);
    ScriveCarattereYX(23,42,4194417);
    ScriveCarattereYX(23,43,4194417);
    ScriveCarattereYX(23,44,4194417);
    ScriveCarattereYX(23,45,4194417);
    ScriveCarattereYX(23,46,4194424);
    ScriveCarattereYX(23,46,4194410);
  }

  if (tentativi >= 2)
    TracciaRettangolo(5,60,12,61);

  if (tentativi >= 3)
  {
    TracciaRettangolo(12,59,14,62);
    ScriveCarattereYX(13,60,'o');
    ScriveCarattereYX(13,61,'o');
  }

  if (tentativi >= 4)
    TracciaRettangolo(14,58,17,63);

  if (tentativi >= 5)
  {
    TracciaRettangolo(17,62,20,63);
    TracciaRettangolo(20,62,21,64);
  }

  if (tentativi >= 6)
  {
    TracciaRettangolo(17,58,20,59);
    TracciaRettangolo(20,57,21,59);
  }

  if (tentativi >= 7)
  {
    TracciaRettangolo(12,65,14,66);
    TracciaRettangolo(14,63,15,66);
  }

  if (tentativi >= 8)
  {
    TracciaRettangolo(12,55,14,56);
    TracciaRettangolo(14,55,15,58);
  }

  SpostaCursore(LINES-1,COLS-1);
  AnnullaImpostazioneColoreTesto(COLOR_RED);
  DisattivaGrassetto();
}

bool presente(char c,string s)
{
  int i;

  for (i=0;i<s.size();i++)
    if (c == s[i])
      return(true);
  return(false);
}

void Visualizza(string s,vector<char> scelte)
{
  int i;
  char c;
  int offset;
  string maschera;

  ImpostaColoreTesto(COLOR_GREEN);
  AttivaGrassetto();
  ScriveYX(0,(COLS-20)/2,"Gioco dell'impiccato");
  offset = (COLS-s.length()*4)/2;
  SpostaCursore(2,offset);
  for (i=0;i<s.length();i++)
    Scrive("  %c ",s[i]);
  AnnullaImpostazioneColoreTesto(COLOR_GREEN);
  for (i=0;i<s.length();i++)
    TracciaRettangolo(1,i*4+offset,3,i*4+4+offset);

  if (impiccato.GetParoleIndovinate())
  {
    ImpostaColoreTesto(COLOR_BLUE);
    ScriveYX(5,0,"Punti %5d - Parole indovinate: %d",impiccato.GetPuntiTotali(),impiccato.GetParoleIndovinate());
    AnnullaImpostazioneColoreTesto(COLOR_BLUE);
  }

  maschera = impiccato.GetMaschera();
  for (c='A',i=0;c<='Z';c++,i++)
  {
    if (count(scelte.begin(),scelte.end(),c) == 1)
      ImpostaColoreTesto(COLOR_RED);
    else if (presente(c,maschera))
      ImpostaColoreTesto(COLOR_GREEN);

    ScriveCarattereYX(9+(i/6)*2,(i%6)*4+2,c);

    if (count(scelte.begin(),scelte.end(),c) == 1)
      AnnullaImpostazioneColoreTesto(COLOR_RED);
    else if (presente(c,maschera))
      AnnullaImpostazioneColoreTesto(COLOR_GREEN);
    TracciaRettangolo(8+(i/6)*2,(i%6)*4,10+(i/6)*2,(i%6)*4+4);
  }
  ScriveYX(17,12,"TENTATIVI");
  TracciaRettangolo(16,8,18,24);
  DisattivaGrassetto();

  SpostaCursore(LINES-1,COLS-1);
}

int main(int argc,char *argv[])
{
  int i;
  int scelta;
  int r,c;
  char cifra;
  char lettera;
  MEVENT evento;

  InizializzazioneNCurses();
  mousemask(BUTTON1_CLICKED,NULL);
  if (argc == 1)
    impiccato.CaricaDizionario("dizionario1.txt");
  else
    impiccato.CaricaDizionario("dizionario2.txt");
  paroleIndovinate = 0;
  do
  {
    if (argc == 3 && strcmp(argv[1],"TEST") == 0)
      impiccato.GeneraNuovaParola(argv[2]);
    else
      impiccato.GeneraNuovaParola();
    do
    {
      Visualizza(impiccato.GetMaschera(),impiccato.GetScelte());
      scelta = LeggeCarattereDaTastiera();
      if (scelta == KEY_MOUSE)
      {
        if (getmouse(&evento) == OK)
        {
          r = (evento.y-9)/2;
          c = (evento.x-2)/4;
          lettera = 'A'+c+r*6;
//          cifra = '8'-r;
          ScriveYX(LINES-1,0,"%c%c R%2d C%2d - HAI PREMUTO LA LETTERA %c",lettera,cifra,r+1,c+1,'A'+(char) (c+r*6));
          AggiornaSchermo();
          scelta = lettera;
          if (impiccato.IsLetteraPresenteInParola(scelta))
          {
          }
        }
      }
      else if (impiccato.IsLetteraPresenteInParola(scelta))
      {
      }
      else if (scelta == KEY_HOME)
        impiccato.SalvaDizionario();
      VisualizzaForca(impiccato.GetTentativi());
    }
    while (scelta != KEY_ESC && !impiccato.IsParolaIndovinata() && !impiccato.IsGiocoFallito());
    Visualizza(impiccato.GetMaschera(),impiccato.GetScelte());
    if (impiccato.IsParolaIndovinata())
    {
      paroleIndovinate++;
      ImpostaColoreTesto(COLOR_GREEN);
      AttivaGrassetto();
      if (paroleIndovinate < MAXPAROLEINDOVINATE)
      {
        ScriveYX(LINES-1,0,"HAI INDOVINATO. BRAVO! - Premi il tasto INVIO per passare alla prossima parola");
      }
      else
        ScriveYX(LINES-1,0,"HAI INDOVINATO. BRAVO! - Premi il tasto INVIO per proseguire");
      AnnullaImpostazioneColoreTesto(COLOR_GREEN);
      DisattivaGrassetto();
      AttendePressioneTasto(KEY_RETURN);
      CancellaSchermo();
    }
  }
  while (scelta != KEY_ESC && !impiccato.IsGiocoFallito() && paroleIndovinate < MAXPAROLEINDOVINATE);
  if (impiccato.IsGiocoFallito())
  {
    Visualizza(impiccato.GetParola(),impiccato.GetScelte());
    VisualizzaForca(MAXTENTATIVI);
    ImpostaColoreTesto(COLOR_RED);
    AttivaGrassetto();
    ScriveYX(LINES-1,0,"HAI PERSO. MI DISPIACE! - Premi il tasto INVIO per terminare");
    AnnullaImpostazioneColoreTesto(COLOR_RED);
    DisattivaGrassetto();
    AttendePressioneTasto(KEY_RETURN);
  }
//  CancellaSchermo();
  else if (impiccato.GetPuntiTotali() > 0)
  {
    ImpostaColoreTesto(COLOR_GREEN);
    AttivaGrassetto();
    VisualizzaTopTen();
    ScriveYX(LINES-2,0,"Hai indovinato %d parole e hai realizzato %d punti.",paroleIndovinate,impiccato.GetPuntiTotali());
    ScriveYX(LINES-1,0,"Inserisci il tuo nome: ");
    SpostaCursore(LINES-1,63);
    AnnullaImpostazioneColoreTesto(COLOR_GREEN);
    ImpostaColoreTesto(COLOR_RED);
    LeggeStringaYX(LINES-1,23,nome,sizeof(nome)-1);
    AnnullaImpostazioneColoreTesto(COLOR_RED);
    impiccato.AccodaNomeNellaTopTen(nome,impiccato.GetPuntiTotali());
    ImpostaColoreTesto(COLOR_RED);
    for (i=0;i<LINES-2;i++)
      CancellaLinea(i,COLS);
    VisualizzaTopTen();
    AnnullaImpostazioneColoreTesto(COLOR_RED);
    ImpostaColoreTesto(COLOR_GREEN);
    ScriveYX(LINES-1,55,"Premere INVIO per uscire");
    SpostaCursore(LINES-1,63);
    AnnullaImpostazioneColoreTesto(COLOR_GREEN);
    DisattivaGrassetto();
    AttendePressioneTasto(KEY_RETURN);
  }

  ChiusuraNCurses();
  return(0);
}
