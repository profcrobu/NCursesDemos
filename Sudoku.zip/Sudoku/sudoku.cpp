#include <iostream>
#include <fstream>
#include <string>

#define ONLYHEADER
#include "accessoNCurses5.h"
#undef ONLYHEADER

#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Sudoku.hpp"

using namespace std;

#define MINCOLONNE 79
#define MINRIGHE   24

//#define DIFFICILE 30
#define NORMALE   50
//#define FACILE    79

int main(int argc,char *argv[])
{
  int livello;
  int carattere;
  Sudoku *sudoku;

  InizializzazioneNCurses();

  if (LINES >= MINRIGHE )
  {
    if (COLS >= MINCOLONNE)
    {
      Sudoku::VisualizzaAnimazione();

      livello = NORMALE;
      if (argc == 2)
      {
        sudoku = new Sudoku(argv[1]);
        if (argv[1][0] != '/')
          sudoku->CaricaSchemaDaFile(argv[1]);
      }
      else
        sudoku = new Sudoku(livello);

      sudoku->VisualizzaIstruzioni();
      do
      {
        sudoku->VisualizzaSchema();
        sudoku->VisualizzaAiuto();

        sudoku->AggiornaPosizione();

        carattere = LeggeCarattereDaTastiera();
#ifdef DEBUG
        cerr << "carattere=" << carattere << endl;
#endif
        if (carattere == KEY_UP)
          sudoku->SpostaSu();
        else if (carattere == KEY_CTRL_UP)
        {
          sudoku->SpostaSu();
          sudoku->SpostaSu();
          sudoku->SpostaSu();
        }
        else if (carattere == KEY_DOWN)
          sudoku->SpostaGiu();
        else if (carattere == KEY_CTRL_DOWN)
        {
          sudoku->SpostaGiu();
          sudoku->SpostaGiu();
          sudoku->SpostaGiu();
        }
        else if (carattere == KEY_LEFT)
          sudoku->SpostaSinistra();
        else if (carattere == KEY_CTRL_LEFT)
        {
          sudoku->SpostaSinistra();
          sudoku->SpostaSinistra();
          sudoku->SpostaSinistra();
        }
        else if (carattere == KEY_RIGHT)
          sudoku->SpostaDestra();
        else if (carattere == KEY_CTRL_RIGHT)
        {
          sudoku->SpostaDestra();
          sudoku->SpostaDestra();
          sudoku->SpostaDestra();
        }
        else if (carattere == KEY_HOME)
          sudoku->SpostaHome();
        else if (carattere == KEY_END)
          sudoku->SpostaEnd();
        else if (carattere == KEY_RETURN && sudoku->UnicaCifra())
          sudoku->InserisceCifra(sudoku->UnicaCifra());
        else if (carattere == KEY_TAB)
          sudoku->SpostaProssimaCellaVuota();
        else if (carattere >= '1' && carattere <= '9' && sudoku->IsCifraReadOnly() == false)
        {
          if (sudoku->IsCifraCompatibile(carattere))
            sudoku->InserisceCifra(carattere);
        }
        else if ((carattere == '0' || carattere == KEY_RETURN) && sudoku->IsCifraCancellabile())
          sudoku->InserisceCifra(' ');
        else if (carattere == 's' || carattere == 'S') // SALVA IL GIOCO SU FILE
        {
          if (sudoku->slivello[0] != '/')
          {
//            sudoku->SalvaSchemaSuFile(sudoku->slivello.c_str());
            sudoku->SalvaSchemaSuFile("sudokuSalvatoSuFileConNome.txt");
//            ScriveYX(LINES-1,COLS-30,"Salvato in '%s'",sudoku->slivello.c_str());
            ScriveYX(LINES-1,COLS-30,"Salvato in 'sudokuSalvatoSuFileConNome.txt'");
          }
          else
          {
            sudoku->SalvaSchemaSuFile("sudokuSalvato.txt");
            ScriveYX(LINES-1,COLS-30,"Salvato in 'sudokuSalvato.txt'");
          }
          AggiornaSchermo();
          Ritardo(2000);
          ScriveYX(LINES-1,COLS-30,"                              ");
        }
        else if (carattere == 'a' || carattere == 'A') // ANNULLA L'ULTIMO INSERIMENTO
        {
          sudoku->AnnullaRegistrazione();
          ScriveYX(LINES-1,COLS-30,"Ultimo inserimento ANNULLATO");
          AggiornaSchermo();
          Ritardo(250);
          ScriveYX(LINES-1,COLS-30,"                              ");
        }
        else if (carattere == 'r' || carattere == 'R') // RIPRISTINA L'ULTIMO INSERIMENTO
        {
          sudoku->RipristinaRegistrazione();
          ScriveYX(LINES-1,COLS-29,"Ultimo inserimento RIPRISTINATO");
          AggiornaSchermo();
          Ritardo(250);
          ScriveYX(LINES-1,COLS-29,"                              ");
        }
      }
      while (carattere != KEY_ESC && sudoku->IsFinitoGioco() == false);
      sudoku->VisualizzaAiuto();

      if (sudoku->IsFinitoGioco())
        sudoku->VisualizzaFinitoGioco();
    }
    else
    {
      Scrive("Questo programma richiede almeno %d colonne.\n",MINCOLONNE);
      Scrive("Premi ESC per uscire\n");
      do
      {
        carattere = LeggeCarattereDaTastiera();
      }
      while (carattere != KEY_ESC);
    }
  }
  else
  {
    Scrive("Questo programma richiede almeno %d righe.\n",MINRIGHE);
    Scrive("Premi ESC per uscire\n");
    do
    {
      carattere = LeggeCarattereDaTastiera();
    }
    while (carattere != KEY_ESC);
  }

  ChiusuraNCurses();
  return(0);
}
