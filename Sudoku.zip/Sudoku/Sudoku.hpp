#include <string>

using namespace std;

typedef struct _SCELTA 
{
  int r,c;
  char carattere;
} SCELTA;

class Sudoku
{
public:
  string slivello;
private:
  int livello; // 30 = difficile, 50 = normale, 70 = facile
  int r,c;
  int centroRiga,centroColonna;

  int posRiga[10];
  int posColonna[10];

  char cifraEvidenziata;
  char sudoku[10][10];
  int readOnly[10][10];
  SCELTA scelte[81];
  int nScelte;
  static void VisualizzaGriglia3x3(int r,int c,int colore);
  void InizializzaDatiCostruttore();
  string CifreUtilizzabili(int r,int c);
  string CifreUniche(int r,int c);
public:
  Sudoku();
  Sudoku(int Livello);
  Sudoku(string Slivello);
  static int SelezionaLivello(string Slivello);
  static void VisualizzaAnimazione();
  void VisualizzaIstruzioni();
  void VisualizzaSchema();
  void VisualizzaInterfacciaUtente();
  void VisualizzaAiuto();
  void VisualizzaFinitoGioco();
  void CaricaSchemaDaFile(char nomefile[]);
  void SalvaSchemaSuFile(char nomefile[]);
  int CifraCompatibilePerRiga(int carattere,int r,int c);
  int CifraCompatibilePerColonna(int carattere,int r,int c);
  int CifraCompatibilePerRiquadro(int carattere,int r,int c);
  char UnicaCifra(); 
  int CaselleVuote();
  bool IsCifraCompatibile(int carattere);
  bool IsCifraCancellabile();
  bool IsCifraReadOnly();
  bool IsFinitoGioco();
  void SpostaProssimaCellaVuota();
  void SpostaSu();
  void SpostaGiu();
  void SpostaSinistra();
  void SpostaDestra();
  void SpostaHome();
  void SpostaEnd();
  void AggiornaPosizione();
  void InserisceCifra(int carattere);
  void AnnullaRegistrazione();
  void RipristinaRegistrazione();
};
