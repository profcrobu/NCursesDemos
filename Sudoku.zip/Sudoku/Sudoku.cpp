#include <iostream>
#include <fstream>
#include <string>

#include <stdlib.h>
#include <time.h>
#include "accessoNCurses5.h"

using namespace std;

#define MINCOLONNE 80
#define MINRIGHE   25

#define VUOTO     0
#define DIFFICILE 30
#define NORMALE   50
#define FACILE    79

#include "Sudoku.hpp"

void Sudoku::VisualizzaGriglia3x3(int r,int c,int colore)
{
  ImpostaColoreTesto(colore);
  AttivaGrassetto();
  TracciaRettangolo(2+r,2+c,4+r,6+c);
  TracciaRettangolo(2+r,6+c,4+r,10+c);
  TracciaRettangolo(2+r,10+c,4+r,14+c);
  TracciaRettangolo(2+r,10+c,4+r,14+c);
  TracciaRettangolo(4+r,2+c,6+r,6+c);
  TracciaRettangolo(4+r,6+c,6+r,10+c);
  TracciaRettangolo(4+r,10+c,6+r,14+c);
  TracciaRettangolo(4+r,10+c,6+r,14+c);
  TracciaRettangolo(6+r,2+c,8+r,6+c);
  TracciaRettangolo(6+r,6+c,8+r,10+c);
  TracciaRettangolo(6+r,10+c,8+r,14+c);
  TracciaRettangolo(6+r,10+c,8+r,14+c);
  DisattivaGrassetto();
  AnnullaImpostazioneColoreTesto(colore);
}

void Sudoku::AnnullaRegistrazione()
{
  if (nScelte)
  {
    nScelte--;
    r = scelte[nScelte].r;
    c = scelte[nScelte].c;
    sudoku[r][c] = ' ';
    ScriveCarattereYX(posRiga[r],posColonna[c],' ');
  }
}

void Sudoku::RipristinaRegistrazione()
{
  if (nScelte<81 && scelte[nScelte].r && scelte[nScelte].c)
  {
    r = scelte[nScelte].r;
    c = scelte[nScelte].c;
    sudoku[r][c] = scelte[nScelte].carattere;
    ScriveCarattereYX(posRiga[r],posColonna[c],scelte[nScelte].carattere);
    nScelte++;
  }
}

int Sudoku::CaselleVuote()
{
  int i,j,cv;

  cv = 0;
  for (i=1;i<=9;i++)
    for (j=1;j<=9;j++)
      if (sudoku[i][j] != ' ')
        cv++;
  return(81-cv);
}

void Sudoku::InizializzaDatiCostruttore()
{
  int i,j,posizione;
  int permutazione[10];

#ifdef DEBUG
  cerr << "Sudoku::Sudoku - Livello = " << livello << endl;
#endif

  cifraEvidenziata = ' ';
  posRiga[0] = 0;
  posRiga[1] = -10;
  posRiga[2] = -8;
  posRiga[3] = -6;
  posRiga[4] = -2;
  posRiga[5] = 0;
  posRiga[6] = 2;
  posRiga[7] = 6;
  posRiga[8] = 8;
  posRiga[9] = 10;

  posColonna[0] = 0;
  posColonna[1] = -18;
  posColonna[2] = -14;
  posColonna[3] = -10;
  posColonna[4] = -2;
  posColonna[5] = 2;
  posColonna[6] = 6;
  posColonna[7] = 14;
  posColonna[8] = 18;
  posColonna[9] = 22;

  for (i=0;i<81;i++)
  {
    scelte[i].r = 0;
    scelte[i].r = 0;
    scelte[i].carattere = 0;
  }
  nScelte = 0;

  for (i=1;i<=9;i++)
    permutazione[i] = 0;

  srand(time(0));
  for (i=1;i<=9;i++)
  {
    do
    {
      posizione = 1+rand()%9;
    }
    while (permutazione[posizione] != 0);
    permutazione[posizione] = i;
  }

  centroRiga = LINES/2;
  centroColonna = 22;

  for (r=1;r<=9;r++)
  {
    posRiga[r] += centroRiga;
#ifdef DEBUG
    cerr << "posRiga[" << r << "]=" << posRiga[r] << endl;
#endif
  }

  for (c=1;c<=9;c++)
  {
    posColonna[c] += centroColonna;
#ifdef DEBUG
    cerr << "posColonna[" << c << "]=" << posColonna[c] << endl;
#endif
  }

#ifdef DEBUG
  cerr << "TRACCIA Costruttore 1" << endl;
#endif
  VisualizzaInterfacciaUtente();
#ifdef DEBUG
  cerr << "TRACCIA Costruttore 2" << endl;
#endif

  for (r=1;r<=9;r++)
    for (c=1;c<=9;c++)
      readOnly[r][c] = 1;

  for (c=1;c<=9;c++)
    sudoku[1][c] = '0'+permutazione[c];

  for (c=1;c<=6;c++)
    sudoku[2][c] = '0'+permutazione[c+3];
  for (c=7;c<=9;c++)
    sudoku[2][c] = '0'+permutazione[c-6];

  for (c=1;c<=3;c++)
    sudoku[3][c] = '0'+permutazione[c+6];
  for (c=4;c<=9;c++)
    sudoku[3][c] = '0'+permutazione[c-3];

  sudoku[4][1] = '0'+permutazione[9];
  for (c=2;c<=9;c++)
    sudoku[4][c] = '0'+permutazione[c-1];

  for (c=1;c<=7;c++)
    sudoku[5][c] = '0'+permutazione[c+2];
  for (c=8;c<=9;c++)
    sudoku[5][c] = '0'+permutazione[c-7];

  for (c=1;c<=4;c++)
    sudoku[6][c] = '0'+permutazione[c+5];
  for (c=5;c<=9;c++)
    sudoku[6][c] = '0'+permutazione[c-4];

  for (c=1;c<=2;c++)
    sudoku[7][c] = '0'+permutazione[c+7];
  for (c=3;c<=9;c++)
    sudoku[7][c] = '0'+permutazione[c-2];

  for (c=1;c<=8;c++)
    sudoku[8][c] = '0'+permutazione[c+1];
  sudoku[8][9] = '0'+permutazione[1];

  for (c=1;c<=5;c++)
    sudoku[9][c] = '0'+permutazione[c+4];
  for (c=6;c<=9;c++)
    sudoku[9][c] = '0'+permutazione[c-5];

#ifdef DEBUG
  cerr << "TRACCIA Costruttore 3" << endl;
#endif
  for (r=1;r<=9;r++)
    for (c=1;c<=9;c++)
      if ((1+rand()%100) > livello)
      {
        sudoku[r][c] = ' ';
        readOnly[r][c] = 0;
      }
  r = 5;
  c = 5;
#ifdef DEBUG
  cerr << "TRACCIA Costruttore 4" << endl;
#endif
}

void Sudoku::VisualizzaAnimazione()
{
  int rC,cC;
  int c;

  rC = 12;
  cC = 40;
  DisattivaCursore();
  for (c = 0; c <= 60 ; c += 15)
  {
    VisualizzaGriglia3x3(0,c+2,c%7);
    SpostaCursore(LINES-1,COLS-1);
    AggiornaSchermo();
    Ritardo(100);
  }

  VisualizzaGriglia3x3(7,60+2,1);
  SpostaCursore(LINES-1,COLS-1);
  AggiornaSchermo();
  Ritardo(100);

  for (c = 60; c >= 0 ; c -= 15)
  {
    VisualizzaGriglia3x3(14,c+2,8-(c+3)%7);
    SpostaCursore(LINES-1,COLS-1);
    AggiornaSchermo();
    Ritardo(100);
  }

  for (c = 0; c < 60 ; c += 15)
  {
    VisualizzaGriglia3x3(7,c+2,8-c%7);
    SpostaCursore(LINES-1,COLS-1);
    AggiornaSchermo();
    Ritardo(100);
  }
  AttivaGrassetto();
  ImpostaColoreTesto(COLOR_BLUE);

  ScriveCarattereYX(rC,cC,'D');
  AggiornaSchermo();
  Ritardo(300);

  ScriveCarattereYX(rC,cC-4,'U');
  ScriveCarattereYX(rC-2,cC,'U');
  ScriveCarattereYX(rC+2,cC,'O');
  ScriveCarattereYX(rC,cC+4,'O');
  AggiornaSchermo();
  Ritardo(300);

  ScriveCarattereYX(rC,cC-11,'S');
  ScriveCarattereYX(rC-5,cC,'S');
  ScriveCarattereYX(rC+5,cC,'K');
  ScriveCarattereYX(rC,cC+11,'K');
  ScriveCarattereYX(rC+7,cC,'U');
  ScriveCarattereYX(rC,cC+15,'U');
  AggiornaSchermo();
  Ritardo(300);

  AnnullaImpostazioneColoreTesto(COLOR_BLUE);
  DisattivaGrassetto();
  AggiornaSchermo();
  Ritardo(2000);
  AttivaCursore();
  CancellaSchermo();
}

bool Sudoku::IsCifraCancellabile()
{
  return(LeggeCarattereYX(posRiga[r],posColonna[c]) != ' ' && readOnly[r][c] == 0);
}

void Sudoku::InserisceCifra(int carattere)
{
  sudoku[r][c] = carattere;
  if (nScelte<81)
  {
    scelte[nScelte].r = r;
    scelte[nScelte].c = c;
    scelte[nScelte].carattere = carattere;
    nScelte++;
    ScriveCarattereYX(posRiga[r],posColonna[c],sudoku[r][c]);
  }
}

void Sudoku::VisualizzaIstruzioni()
{
  ImpostaColoreTesto(COLOR_GREEN);
  if (slivello == "")
    ScriveYX(0,posColonna[9]+6,"Livello: %s",(livello == FACILE) ? "FACILE" : ((livello == NORMALE) ? "NORMALE" : ((livello == DIFFICILE) ? "DIFFICILE" : " - ")));
  else
    ScriveYX(0,posColonna[9]+6,"%s",slivello.c_str());
//    ScriveYX(0,posColonna[9]+6,"Livello: %s",slivello.c_str());
  AnnullaImpostazioneColoreTesto(COLOR_GREEN);
  AttivaGrassetto();
  ImpostaColoreTesto(COLOR_YELLOW);  
  ScriveYX(posRiga[5]-10,posColonna[9]+6,"Comandi attivi");
  AnnullaImpostazioneColoreTesto(COLOR_YELLOW);
  ScriveYX(posRiga[5]-8,posColonna[9]+6,"ESC   Uscita");
  ScriveYX(posRiga[5]-6,posColonna[9]+6,"Frecce del cursore");
  ScriveYX(posRiga[5]-5,posColonna[9]+6,"1-9   Segna cifra");
  ScriveYX(posRiga[5]-4,posColonna[9]+6,"0     Cancella cifra");
  ScriveYX(posRiga[5]-2,posColonna[9]+6,"A     Annulla inserimento");
  ScriveYX(posRiga[5]-1,posColonna[9]+6,"R     Ripete inserimento");
  ScriveYX(posRiga[5]+1,posColonna[9]+6,"TAB   Trova cella libera");
  ScriveYX(posRiga[5]+2,posColonna[9]+6,"INVIO Inserisce cifra unica");
  ScriveYX(posRiga[5]+6,posColonna[9]+6,"S     Salva su file");
  DisattivaGrassetto();
  ScriveYX(posRiga[5]+10,posColonna[9]+6,"Cifre uniche: ");
  ScriveYX(posRiga[5]+11,posColonna[9]+6,"Caselle vuote: ");
  TracciaRettangolo(posRiga[5]+7,posColonna[9]+6,posRiga[5]+9,posColonna[9]+16);
  ImpostaColoreTesto(COLOR_YELLOW);
  AttivaGrassetto();
  ScriveYX(posRiga[5]+8,posColonna[9]+17,"Cifre utilizzabili");
  DisattivaGrassetto();
  AnnullaImpostazioneColoreTesto(COLOR_YELLOW);
#ifdef DEBUG
  cerr << "TRACCIA VisualizzaIstruzioni" << endl;
#endif
}

void Sudoku::VisualizzaSchema()
{
  int riga,colonna;

  cifraEvidenziata = LeggeCarattereYX(posRiga[r],posColonna[c]);
  for (riga=1;riga<=9;riga++)
  {
    for (colonna=1;colonna<=9;colonna++)
    {
      if (sudoku[riga][colonna] == cifraEvidenziata)
      {
        ImpostaColoreTesto(COLOR_RED);
        ScriveCarattereYX(posRiga[riga],posColonna[colonna],sudoku[riga][colonna] | A_BOLD);
        AnnullaImpostazioneColoreTesto(COLOR_RED);
      }
      else if (sudoku[riga][colonna] != ' ' && readOnly[riga][colonna])
      {
        ImpostaColoreTesto(COLOR_YELLOW);
        ScriveCarattereYX(posRiga[riga],posColonna[colonna],sudoku[riga][colonna] | A_BOLD);
        AnnullaImpostazioneColoreTesto(COLOR_YELLOW);
      }
      else if (sudoku[riga][colonna] != ' ')
        ScriveCarattereYX(posRiga[riga],posColonna[colonna],sudoku[riga][colonna]);
      else
        ScriveCarattereYX(posRiga[riga],posColonna[colonna],' ');
    }
  }
#ifdef DEBUG
  cerr << "TRACCIA VisualizzaSchema" << endl;
#endif
}

void Sudoku::VisualizzaInterfacciaUtente()
{
  int r,c,k,kr,kc;

  AttivaGrassetto();

  for (r=0;r<3;r++)
    for (c=0;c<3;c++)
    {
      TracciaRettangolo(posRiga[3*r+1]-2,posColonna[3*c+1]-4,posRiga[3*r+1]+6,posColonna[3*c+1]+12);
#ifdef DEBUG
      cerr << "TracciaRettangolo(" << posRiga[3*r+1]-4 << "," << posColonna[3*c+1]-8 << "," << posRiga[3*r+1]+4 << "," << posColonna[3*c+1]+8 <<")" << endl;
#endif
    }

  for (kr=0;kr<3;kr++)
    for (kc=0;kc<3;kc++)
    {
      k = kr+kc;
      ImpostaColoreTesto(2*(k%2)+2);
#ifdef DEBUG
      cerr << "k=" << k << endl;
      cerr << "ImpostaColoreTesto=" << 2*(k%2)+2 << endl;
#endif
      for (r=1;r<=3;r++)
      {
        for (c=1;c<=3;c++)
        {
          TracciaRettangolo(posRiga[3*kr+r]-1,posColonna[3*kc+c]-2,posRiga[3*kr+r]+1,posColonna[3*kc+c]+2);
#ifdef DEBUG
          cerr << "TracciaRettangolo(" << posRiga[3*kr+r]-1 << "," << posColonna[3*kc+c]-2 << "," << posRiga[3*kr+r]+1 << "," << posColonna[3*kc+c]+2 <<")" << endl;
#endif
        }
      }
      AnnullaImpostazioneColoreTesto(2*(k%2)+2);
#ifdef DEBUG
      cerr << "AnnullaColoreTesto=" << 2*(k%2)+2 << endl;
#endif
    }
  DisattivaGrassetto();
#ifdef DEBUG
  cerr << "TRACCIA VisualizzaInterfacciaUtente" << endl;
#endif
}

Sudoku::Sudoku(int Livello)
{
  livello = Livello;
  if (livello == NORMALE)
    slivello = "NORMALE";
  else if (livello == FACILE)
    slivello = "FACILE";
  else if (livello == DIFFICILE)
    slivello = "DIFFICILE";
  else if (livello == VUOTO)
    slivello = "VUOTO";
  InizializzaDatiCostruttore();
}

Sudoku::Sudoku(string Slivello)
{
  if (Slivello == "/facile")
  {
    livello = FACILE;
    slivello = "FACILE";
  }
  else if (Slivello == "/normale")
  {
    livello = NORMALE;
    slivello = "NORMALE";
  }
  else if (Slivello == "/difficile")
  {
    livello = DIFFICILE;
    slivello = "DIFFICILE";
  }
  else if (Slivello == "/vuoto")
  {
    livello = VUOTO;
    slivello = "VUOTO";
  }
  InizializzaDatiCostruttore();
}

Sudoku::Sudoku()
{
  livello = NORMALE;
  slivello = "NORMALE";
  InizializzaDatiCostruttore();
}

void Sudoku::CaricaSchemaDaFile(char nomefile[])
{
  FILE *f;
  int i,j,k,kk;
  char riga[101];

  slivello = string(nomefile);
  if ((f = fopen(nomefile,"rt")) != NULL)
  {
    for (i=0;i<3;i++)
    {
      for (j=0;j<3;j++)
      {
        fgets(riga,sizeof(riga)-1,f);
        for (k=0,kk=1;k<11,kk<=9;k++,kk++)
        {
          if (riga[k] >= '1' && riga[k] <= '9')
          {
            sudoku[i*3+j+1][kk] = riga[k];
            readOnly[i*3+j+1][kk] = 1;
          }
          else if (riga[k] == '-')
          {
            sudoku[i*3+j+1][kk] = ' ';
            readOnly[i*3+j+1][kk] = 0;
          }
          else if (riga[k] == ' ')
            kk--;
        }
      }
      if (i < 3)
        fgets(riga,sizeof(riga)-1,f);
    }
    fclose(f);
  }
}

void Sudoku::SalvaSchemaSuFile(char nomefile[])
{
  FILE *f;
  int i,j,k,kk;
  char riga[101];

  if ((f = fopen(nomefile,"wt")) != NULL)
  {
    slivello = string(nomefile);
    for (i=0;i<3;i++)
    {
      for (j=0;j<3;j++)
      {
        for (k=1;k<=9;k++)
        {
          if (sudoku[i*3+j+1][k] != ' ')
            fputc(sudoku[i*3+j+1][k],f);
          else
            fputc('-',f);
          if (k == 3 || k == 6)
            fputc(' ',f);
        }
        fputc('\n',f);
      }
      fputc('\n',f);
    }
    fclose(f);
  }
}

int Sudoku::CifraCompatibilePerRiga(int carattere,int r,int c)
// restituisce 1 se la cifra inserita e' valida per la riga corrispondente, 0 altrimenti
{
  int colonna;

  for (colonna=1;colonna<=9;colonna++)
    if (colonna != c && sudoku[r][colonna] == carattere)
      return(0);
  return(1);
}

int Sudoku::CifraCompatibilePerColonna(int carattere,int r,int c)
// restituisce 1 se la cifra inserita e' valida per la colonna corrispondente, 0 altrimenti
{
  int riga;

  for (riga=1;riga<=9;riga++)
    if (riga != r && sudoku[riga][c] == carattere)
      return(0);
  return(1);
}

int Sudoku::CifraCompatibilePerRiquadro(int carattere,int r,int c)
// restituisce 1 se la cifra inserita e' valida per il riquadro corrispondente, 0 altrimenti
{
  int riga;
  int colonna;
  int rInizioRiquadro;
  int cInizioRiquadro;

  rInizioRiquadro = ((r-1)/3)*3+1;
  cInizioRiquadro = ((c-1)/3)*3+1;

  for (riga=rInizioRiquadro;riga<=rInizioRiquadro+2;riga++)
    for (colonna=cInizioRiquadro;colonna<=cInizioRiquadro+2;colonna++)
      if (riga != r && colonna != c && sudoku[riga][colonna] == carattere)
        return(0);
  return(1);
}

bool Sudoku::IsCifraCompatibile(int carattere)
// restituisce 1 se la cifra inserita e' valida per lo schema corrente, 0 altrimenti
{
  if (CifraCompatibilePerRiga(carattere,r,c))
    if (CifraCompatibilePerColonna(carattere,r,c))
      if (CifraCompatibilePerRiquadro(carattere,r,c))
        return(true);
  return(false);
}

string Sudoku::CifreUtilizzabili(int r,int c)
{
  string cifre = "123456789";
  char valore;
  int y,x;

#ifdef DEBUG
  cerr << "TRACCIA CifreUtilizzabili 1" << endl;
#endif
#ifdef DEBUG
  cerr << "TRACCIA CifreUtilizzabili 2" << endl;
#endif
#ifdef DEBUG
  cerr << "TRACCIA CifreUtilizzabili 3" << endl;
#endif
  if (sudoku[r][c] != ' ')
    cifre = "         ";
  for (x=1;x<=9;x++)
  {
    valore = sudoku[r][x];
    if ((sudoku[r][c] != valore && valore != ' ') || readOnly[r][c])
      cifre[valore-'0'-1] = ' ';
  }
  for (y=1;y<=9;y++)
  {
    valore = sudoku[y][c];
    if ((sudoku[r][c] != valore && valore != ' ') || readOnly[r][c])
      cifre[valore-'0'-1] = ' ';
  }
  for (x=1;x<=9;x++)
  {
    if (cifre[x-1] != ' ')
      if (CifraCompatibilePerRiquadro(cifre[x-1],r,c) == 0)
        cifre[x-1] = ' ';
  }
  return(cifre);
}

string Sudoku::CifreUniche(int r,int c)
{
  int cont[9];
  string spazi = "         ";
  string cifre;
  char valore;
  int i;
  int riga;
  int colonna;
  int rInizioRiquadro;
  int cInizioRiquadro;

  rInizioRiquadro = ((r-1)/3)*3+1;
  cInizioRiquadro = ((c-1)/3)*3+1;


#ifdef DEBUG
  cerr << "TRACCIA CifreUniche 1" << endl;
#endif
  for (i=0;i<9;i++)
    cont[i] = 0;
#ifdef DEBUG
  cerr << "TRACCIA CifreUniche 2" << endl;
#endif
  for (riga=rInizioRiquadro;riga<=rInizioRiquadro+2;riga++)
    for (colonna=cInizioRiquadro;colonna<=cInizioRiquadro+2;colonna++)
      if ((cifre = CifreUtilizzabili(riga,colonna)) != spazi)
       for (i=0;i<9;i++)
         if (cifre[i] != ' ')
           cont[i]++;
  cifre = "         ";
  for (i=0;i<9;i++)
    if (cont[i] == 1)
      cifre[i] = '1'+i;        
#ifdef DEBUG
  cerr << "cifre = " << cifre << endl;
  cerr << "TRACCIA CifreUniche 3" << endl;
#endif
  return(cifre);
}

void Sudoku::VisualizzaAiuto()
{
  string cifre;
  string cifreUniche;

#ifdef DEBUG
  cerr << "TRACCIA VisualizzaAiuto 1 [r=" << r << ",c=" << c << "]" << endl;
#endif
  cifre = CifreUtilizzabili(r,c);
  cifreUniche = CifreUniche(r,c);
  ImpostaColoreTesto(COLOR_YELLOW);
  AttivaGrassetto();
  ScriveYX(posRiga[5]+8,posColonna[9]+7,"%9s",cifre.c_str());
  DisattivaGrassetto();
  ScriveYX(posRiga[5]+10,posColonna[9]+21,"%s",cifreUniche.c_str());
  AnnullaImpostazioneColoreTesto(COLOR_YELLOW);
  ImpostaColoreTesto(COLOR_RED);
  ScriveYX(posRiga[5]+11,posColonna[9]+21,"%2d",CaselleVuote());
  AnnullaImpostazioneColoreTesto(COLOR_RED);
#ifdef DEBUG
  cerr << "TRACCIA VisualizzaAiuto 2" << endl;
#endif
}

bool Sudoku::IsFinitoGioco()
{
  int r,c;

  for (r=1;r<=9;r++)
    for (c=1;c<=9;c++)
      if (sudoku[r][c] == ' ')
        return(false);
  return(true);
}

void Sudoku::VisualizzaFinitoGioco()
{
  int i,carattere;

  AttivaGrassetto();
  for (i=1;i<LINES;i++)
    ScriveYX(i,posColonna[9]+6,"                             ");
  TracciaRettangolo(posRiga[5]-6,posColonna[9]+5,posRiga[5]+4,posColonna[9]+34);
  ScriveYX(posRiga[5]-4,posColonna[9]+6,"       COMPLIMENTI !    ");
  DisattivaGrassetto();                      
  ImpostaColoreTesto(COLOR_GREEN);
  ScriveYX(posRiga[5]-2,posColonna[9]+6,"      HAI COMPLETATO    ");
  ScriveYX(posRiga[5],posColonna[9]+6,"       QUESTO SUDOKU    ");
  AnnullaImpostazioneColoreTesto(COLOR_GREEN);
  AttivaGrassetto();
  ScriveYX(posRiga[5]+2,posColonna[9]+6,"    Premi ESC per uscire");
  ImpostaColoreTesto(COLOR_RED);
  ScriveYX(posRiga[5]+2,posColonna[9]+16,"ESC");
  AnnullaImpostazioneColoreTesto(COLOR_RED);
  DisattivaGrassetto();                      
  do
  {
    SpostaCursore(posRiga[5]+2,posColonna[9]+17);
    carattere = LeggeCarattereDaTastiera();
  }
  while (carattere != KEY_ESC);
}

void Sudoku::SpostaProssimaCellaVuota()
{
  if (c < 9)
    c++;
  else if (r < 9)
  {
    r++;
    c = 1;
  }
  else
  {
    r = 1;
    c = 1;
  }
  while (sudoku[r][c] != ' ')
  {
    if (c < 9)
      c++;
    else if (r < 9)
    {
      r++;
      c = 1;
    }
    else
    {
      r = 1;
      c = 1;
    }
    SpostaCursore(posRiga[r],posColonna[c]);
    AggiornaSchermo();
  }
}

void Sudoku::SpostaSu()
{
  if (r > 1)
    r--;
  else
    r = 9;
}

void Sudoku::SpostaGiu()
{
  if (r < 9)
    r++;
  else
    r = 1;
}

void Sudoku::SpostaSinistra()
{
  if (c > 1)
    c--;
  else
    c = 9;
}

void Sudoku::SpostaDestra()
{
  if (c < 9)
    c++;
  else
    c = 1;
}


void Sudoku::SpostaHome()
{
  r = 1;
  c = 1;
}

void Sudoku::SpostaEnd()
{
  r = 9;
  c = 9;
}

void Sudoku::AggiornaPosizione()
{
  SpostaCursore(posRiga[r],posColonna[c]);
  AggiornaSchermo();
}

bool Sudoku::IsCifraReadOnly()
{
  return(readOnly[r][c]);
}

char Sudoku::UnicaCifra()
{
  string cifre;
  char cifra;
  int i;

  cifra = ' ';
  cifre = CifreUtilizzabili(r,c);
  for (i=0;i<cifre.length();i++)
    if (cifre[i] != ' ')
    {
      if (cifra != ' ')
        return(' ');
      else
        cifra = cifre[i];
    }
  return(cifra);     
}
