#include <iostream>
#include <locale.h>
#include <stdlib.h>
#include <time.h>

#include "accessoNCurses4w.h"

using namespace std;

#define KEY_RETURN 13
#define KEY_TAB    9
#define KEY_ESC    27

#define REB      "\u2654"
#define REGINAB  "\u2655"
#define TORREB   "\u2656"
#define ALFIEREB "\u2657"
#define CAVALLOB "\u2658"
#define PEDONEB  "\u2659"

#define REN      "\u265A"
#define REGINAN  "\u265B"
#define TORREN   "\u265C"
#define ALFIEREN "\u265D"
#define CAVALLON "\u265E"
#define PEDONEN  "\u265F"

int r,c;
int r1,c1;
int r2,c2;
int click;
char cifra;
char lettera;
char scacchiera[8][8];

void SegnalaSpostamento()
{
  if (r == 1 && scacchiera[r][c] == 'p')
    r = r+2;
  else if (r == 6 && scacchiera[r][c] == 'P')
    r = r-2;
  else if (scacchiera[r][c] == 'C')
  {
    r = r-2;
    c = c+1;
  }
  else if (scacchiera[r][c] == 'c')
  {
    r = r+2;
    c = c+1;
  }
}

void VisualizzaPezzo(char pezzo)
{
  if (pezzo == 'K')
    addstr(REB);
  else if (pezzo == 'Q')
    addstr(REGINAB);
  else if (pezzo == 'R')
    addstr(TORREB);
  else if (pezzo == 'B')
    addstr(ALFIEREB);
  else if (pezzo == 'C')
    addstr(CAVALLOB);
  else if (pezzo == 'P')
    addstr(PEDONEB);
  else if (pezzo == 'k')
    addstr(REN);
  else if (pezzo == 'q')
    addstr(REGINAN);
  else if (pezzo == 'r')
    addstr(TORREN);
  else if (pezzo == 'b')
    addstr(ALFIEREN);
  else if (pezzo == 'c')
    addstr(CAVALLON);
  else if (pezzo == 'p')
    addstr(PEDONEN);
}

void InizializzaScacchiera()
{
  int i,j;

  for (i=0;i<8;i++)
    for (j=0;j<8;j++)
      scacchiera[i][j] = ' ';
  for (j=0;j<8;j++)
    scacchiera[1][j] = 'p';
  scacchiera[0][0] = 'r';
  scacchiera[0][1] = 'c';
  scacchiera[0][2] = 'b';
  scacchiera[0][3] = 'q';
  scacchiera[0][4] = 'k';
  scacchiera[0][5] = 'b';
  scacchiera[0][6] = 'c';
  scacchiera[0][7] = 'r';
  for (j=0;j<8;j++)
    scacchiera[6][j] = 'P';
  scacchiera[7][0] = 'R';
  scacchiera[7][1] = 'C';
  scacchiera[7][2] = 'B';
  scacchiera[7][3] = 'Q';
  scacchiera[7][4] = 'K';
  scacchiera[7][5] = 'B';
  scacchiera[7][6] = 'C';
  scacchiera[7][7] = 'R';
}

void VisualizzaScacchiera()
{
  int i,j;

  TracciaRettangolo(0,0,19,36);
  for (i=0;i<8;i++)
  {
    for (j=0;j<8;j++)
    {
      TracciaRettangolo(1+2*i,2+4*j,3+2*i,6+4*j);
      if (((i+j) % 2) == 0)
      {
        attron(A_REVERSE);
        ScriveCarattereYX(2+i*2,3+j*4,' ');
        ScriveCarattereYX(2+i*2,4+j*4,' ');
        ScriveCarattereYX(2+i*2,5+j*4,' ');
        attroff(A_REVERSE);
      }
      else
        ScriveCarattereYX(2+i*2,4+j*4,' ');
      SpostaCursore(2+i*2,4+j*4);
      VisualizzaPezzo(scacchiera[7-i][j]);
    }
    ScriveCarattereYX(2+i*2,1,'0'+8-i);
    ScriveCarattereYX(18,4+i*4,'A'+i);
  }
  AggiornaSchermo();
}

void GestisceSelezionePezzo()
{
  click++;
  if ((click%2) == 1)
  {
    r1 = r;
    c1 = c;
    ScriveYX(1,39,"Spostamento da %c%c R%d C%d",lettera,cifra,r+1,c+1);
    ScriveYX(2,39,"                           ",lettera,cifra,r+1,c+1);
  }
  else
  {
    r2 = r;
    c2 = c;
    if ((r1 != r2) || (c1 != c2))
    {
      scacchiera[7-r2][c2] = scacchiera[7-r1][c1];
      scacchiera[7-r1][c1] = ' ';
      ScriveYX(2,39,"             a %c%c R%d C%d",lettera,cifra,r+1,c+1);
    }
  }
}

int main()
{
  int i,mano,scelta;
  MEVENT evento;

  srand(time(0));
  setlocale(LC_ALL,"");
  InizializzazioneNCurses();
  mousemask(BUTTON1_CLICKED,NULL);
  AttivaGrassetto();

  click = 0;
  InizializzaScacchiera();
  ScriveYX(LINES-1,COLS-5,"%dx%d",LINES,COLS);
  do
  {
    VisualizzaScacchiera();
    SpostaCursore(2+r*2,4+c*4);
    scelta = LeggeCarattereDaTastiera();
    if (scelta == KEY_MOUSE)
    {
      if (getmouse(&evento) == OK)
      {
        r = (evento.y-2)/2;
        c = (evento.x-4)/4;
        lettera = 'A'+c;
        cifra = '8'-r;
//        ScriveYX(1,COLS-9,"%c%c R%d C%d",lettera,cifra,r+1,c+1);
        AggiornaSchermo();
        GestisceSelezionePezzo();
      }
    }
    else if (scelta == KEY_DOWN)
      r = (r+1) % 8;
    else if (scelta == KEY_UP)
      r = (r-1) % 8;
    else if (scelta == KEY_RIGHT)
      c = (c+1) % 8;
    else if (scelta == KEY_LEFT)
      c = (c-1) % 8;
    else if (scelta == KEY_TAB)
    {
      r = r1;
      c = c1;
      SegnalaSpostamento();
    }
    else if (scelta == KEY_RETURN)
    {
      lettera = 'A'+c;
      cifra = '8'-r;
      GestisceSelezionePezzo();
    }
  }
  while (scelta != 'q' && scelta != 'Q' && scelta != KEY_ESC);

  ChiusuraNCurses();
  return(0);
}
