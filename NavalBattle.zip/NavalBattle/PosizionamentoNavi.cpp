#define NAVE  'X'
#define SEGNALATORE 'O'
#define ACQUA ' '

#define ORIZZONTALE 0
#define VERTICALE   1

int TentaPosizionamentoNave(int riga,int colonna,int nr,int nc,int caselle,int orientamento,int r,int c,int invisibile)
// PARAMETRI E RELATIVO SIGNIFICATO
//
// riga			riga della casella iniziale del quadrante
// colonna		colonna della casella iniziale del quadrante
// nr			n.ro di righe del quadrante della battaglia navale
// nc			n.ro di colonne del quadrante della battaglia navale
// caselle		n.ro di caselle occupate dalla nave
// orientamento		orizzontale(=0) o verticale(=1)
// r			riga della casella iniziale della nave
// c			colonna della casella iniziale della nave
// invisibile		=1 navi invisibili, =0 navi visibili
{
  int i;

  fprintf(stderr,"PosizionaSingolaNave\n");
  fprintf(stderr,"CASELLE %d\n",caselle);
  fprintf(stderr,"ORIENTAMENTO %d\n",orientamento);
  fprintf(stderr,"RIGA %d\n",riga);
  fprintf(stderr,"COLONNA %d\n",colonna);
  fprintf(stderr,"R %d\n",r);
  fprintf(stderr,"C %d\n",c);
  fprintf(stderr,"NR %d\n",nr);
  fprintf(stderr,"NC %d\n\n",nc);
  if (caselle < 2 || caselle > 5) // sono AMMESSE solo navi da 2, 3, 4 e 5
  {
    fprintf(stderr,"CASELLE invalido\n\n");
    return(FALSE);
  }
  if (nr < 8 || nc < 8) // sono AMMESSI quadranti almeno 8x8
  {
    fprintf(stderr,"NR o NC invalidi\n\n");
    return(FALSE);
  }
  if (r < 0 || r >= nr || c < 0 || c >= nc) // sono AMMESSI solo valori validi
  {
    fprintf(stderr,"R o C invalidi\n\n");
    return(FALSE);
  }
  if (orientamento == ORIZZONTALE)
  {
    if (c+caselle > nc)
    {
      fprintf(stderr,"C+CASELLE invalido\n\n");
      return(FALSE);
    }
    for (i=0;i<caselle;i++)
      if (LeggeCarattereYX(riga+r,colonna+c+i) != ACQUA)
        return(FALSE);
    ScriveCarattereYX(riga+r-1,colonna+c-1,SEGNALATORE);
    ScriveCarattereYX(riga+r,colonna+c-1,SEGNALATORE);
    ScriveCarattereYX(riga+r+1,colonna+c-1,SEGNALATORE);
    for (i=0;i<caselle;i++)
    {
      ScriveCarattereYX(riga+r-1,colonna+c+i,SEGNALATORE);
      if (invisibile)
        ScriveCarattereYX(riga+r,colonna+c+i,NAVE|A_INVIS);
      else
        ScriveCarattereYX(riga+r,colonna+c+i,NAVE);
      ScriveCarattereYX(riga+r+1,colonna+c+i,SEGNALATORE);
    }
    ScriveCarattereYX(riga+r-1,colonna+c+caselle,SEGNALATORE);
    ScriveCarattereYX(riga+r,colonna+c+caselle,SEGNALATORE);
    ScriveCarattereYX(riga+r+1,colonna+c+caselle,SEGNALATORE);
    return(TRUE);
  }
  else if (orientamento == VERTICALE)
  {
    if (r+caselle > nr)
    {
      fprintf(stderr,"R+CASELLE invalido\n\n");
      return(FALSE);
    }
    for (i=0;i<caselle;i++)
      if (LeggeCarattereYX(riga+r+i,colonna+c) != ACQUA)
        return(FALSE);
    ScriveCarattereYX(riga+r-1,colonna+c-1,SEGNALATORE);
    ScriveCarattereYX(riga+r-1,colonna+c,SEGNALATORE);
    ScriveCarattereYX(riga+r-1,colonna+c+1,SEGNALATORE);
    for (i=0;i<caselle;i++)
    {
      ScriveCarattereYX(riga+r+i,colonna+c-1,SEGNALATORE);
      if (invisibile)
        ScriveCarattereYX(riga+r+i,colonna+c,NAVE|A_INVIS);
      else
        ScriveCarattereYX(riga+r+i,colonna+c,NAVE);
      ScriveCarattereYX(riga+r+i,colonna+c+1,SEGNALATORE);
    }
    ScriveCarattereYX(riga+r+caselle,colonna+c-1,SEGNALATORE);
    ScriveCarattereYX(riga+r+caselle,colonna+c,SEGNALATORE);
    ScriveCarattereYX(riga+r+caselle,colonna+c+1,SEGNALATORE);
    return(TRUE);
  }
  else
  {
    fprintf(stderr,"ERRORE generico\n\n");
    return(FALSE);
  }
}

void PosizionaSingolaNave(int riga,int colonna,int nr,int nc,int caselle,int invisibile)
// PARAMETRI E RELATIVO SIGNIFICATO
//
// riga		riga della prima casella (in alto a sinistra) del quadrante
// colonna	colonna della prima casella (in alto a sinistra) del quadrante
// nr		n.ro di righe del quadrante della battaglia navale
// nc		n.ro di colonne del quadrante della battaglia navale
// caselle		n.ro di caselle occupate dalla nave
// invisibile		se è diverso da 0 posiziona la nave con l'attributo di invisibilità (A_INVIS), altrimenti la rende visibile
{
  int orientamento,r,c;
  int successo;

  fprintf(stderr,"PosizionaSingolaNave\n");
  do
  {
    orientamento = rand()%2; // 0=ORIZZONTALE 1=VERTICALE
    fprintf(stderr,"ORIENTAMENTO %d\n",orientamento);
    if (orientamento == ORIZZONTALE)
    {
      r = 1+rand()%nr; // genera valori nell'intervallo [0,nr-1]
      fprintf(stderr,"R %d\n",r);
      c = 1+rand()%(nc-caselle); // genera valori nell'intervallo [0,nc-1]
      fprintf(stderr,"C %d\n\n",c);
    }
    else
    {
      r = 1+rand()%(nr-caselle); // genera valori nell'intervallo [0,nr-1]
      fprintf(stderr,"R %d\n",r);
      c = 1+rand()%nc; // genera valori nell'intervallo [0,nc-1]
      fprintf(stderr,"C %d\n\n",c);
    }
    successo = TentaPosizionamentoNave(riga,colonna,nr,nc,caselle,orientamento,r,c,invisibile);
  }
  while (successo == FALSE);
}

void RipulisceSegnalatori(int riga,int colonna,int nr,int nc)
// PARAMETRI E RELATIVO SIGNIFICATO
//
// riga		riga della prima casella (in alto a sinistra) del quadrante
// colonna	colonna della prima casella (in alto a sinistra) del quadrante
// nr		n.ro di righe del quadrante della battaglia navale
// nc		n.ro di colonne del quadrante della battaglia navale
{
  int i,j;

  for (i=riga;i<riga+nr;i++)
    for (j=colonna;j<colonna+nc;j++)
      if (LeggeCarattereYX(i,j) == SEGNALATORE)
        ScriveCarattereYX(i,j,' ');
}

void PosizionaNavi(int riga,int colonna,int nr,int nc,int n5,int n4,int n3,int n2,int invisibile)
// PARAMETRI E RELATIVO SIGNIFICATO
//
// riga		riga della prima casella (in alto a sinistra) del quadrante
// colonna	colonna della prima casella (in alto a sinistra) del quadrante
// nr		n.ro di righe del quadrante della battaglia navale
// nc		n.ro di colonne del quadrante della battaglia navale
// n5		n.ro di navi da 5 caselle da posizionare (portaerei?)
// n4		n.ro di navi da 4 caselle da posizionare (corazzate?)
// n3		n.ro di navi da 3 caselle da posizionare (incrociatori?)
// n2		n.ro di navi da 2 caselle da posizionare (cacciatorpediniere?)
// invisibile	se è diverso da 0 posiziona le navi con l'attributo di invisibilità (A_INVIS), altrimenti le rende visibili
{
  int i;

  fprintf(stderr,"PosizionamentoNavi\n");
  for (i=1;i<=n5;i++)
    PosizionaSingolaNave(riga,colonna,nr,nc,5,invisibile);
  for (i=1;i<=n4;i++)
    PosizionaSingolaNave(riga,colonna,nr,nc,4,invisibile);
  for (i=1;i<=n3;i++)
    PosizionaSingolaNave(riga,colonna,nr,nc,3,invisibile);
  for (i=1;i<=n2;i++)
    PosizionaSingolaNave(riga,colonna,nr,nc,2,invisibile);
  RipulisceSegnalatori(riga,colonna,nr,nc);
}
