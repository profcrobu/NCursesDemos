/***********************************************************/
/*   LIBRERIA DI SEMPLIFICAZIONE PER L'USO DELLE NCURSES   */
/*   Versione 4.0                                          */	
/*   Aggiornamento al 2 aprile 2011                        */
/***********************************************************/

#include <curses.h>
#include <string.h>

#define AggiornaSchermo refresh
#define LeggeCarattereDaTastiera getch
#define LeggePosizioneCursore(y,x) getyx(stdscr,y,x)
#define LeggeStringaYXNoEcho(y,x,s,n) mvgetnstr(y,x,s,n)
#define Scrive  printw
#define ScriveCarattereYX mvaddch
#define ScriveYX  mvprintw
#define SpostaCursore move
#define AttivaCursore() cursor_vis(1)
#define DisattivaCursore() cursor_vis(0)

void LeggeStringaYX(int y,int x,char *s,int n)
{
  echo();
  mvgetnstr(y,x,s,n);
  noecho();
}

void cursor_vis(int vis)
{
  char *cmd;
	
  if (vis == 1)
    cmd = tigetstr("cnorm");
  else
    cmd = tigetstr("civis");
	
  if (cmd == (char *)-1)
  {
    fprintf(stderr, "Attenzione! Il vostro terminale non supporta il comando CURSOR ON/OFF\n");
    sleep(3);
    return;
  }
  putp(cmd);
}

int LeggeCarattereYX(int y,int x)
{
  return(mvinch(y,x) & A_CHARTEXT);
}

int LeggeAttributoYX(int y,int x)
{
  return(mvinch(y,x) & A_ATTRIBUTES);
}

void AttivaGrassetto()
{
  attron(A_BOLD);
}

void DisattivaGrassetto()
{
  attroff(A_BOLD);
}

void ImpostaColoreSfondo(int colore)
{
  bkgd(COLOR_PAIR(colore));
}

void ImpostaColoreTesto(int colore)
{
  attron(COLOR_PAIR(colore));
}

void AnnullaImpostazioneColoreTesto(int colore)
{
  attroff(COLOR_PAIR(colore));
}

void CancellaLinea(int riga,int numeroCaratteri)
{
  int c;

  for (c=0;c<numeroCaratteri;c++)
    ScriveCarattereYX(riga,c,' ');
}

void CancellaSchermo()
{
  int r;

  clear();
/*
  for (r=0;r<LINES-1;r++)
    CancellaLinea(r,COLS);
*/
}

void InizializzazioneNCurses()
{
  initscr();
  start_color();
  if (has_colors())
  {
    start_color();
    init_pair(COLOR_BLACK, COLOR_BLACK, COLOR_BLACK);
    init_pair(COLOR_GREEN, COLOR_GREEN, COLOR_BLACK);
    init_pair(COLOR_RED, COLOR_RED, COLOR_BLACK);
    init_pair(COLOR_CYAN, COLOR_CYAN, COLOR_BLACK);
    init_pair(COLOR_WHITE, COLOR_WHITE, COLOR_BLACK);
    init_pair(COLOR_MAGENTA, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(COLOR_BLUE, COLOR_BLUE, COLOR_BLACK);
    init_pair(COLOR_YELLOW, COLOR_YELLOW, COLOR_BLACK);

    init_pair(9, COLOR_BLUE, COLOR_WHITE);
    init_pair(10, COLOR_YELLOW, COLOR_WHITE);
  }
  cbreak();
  nonl();
  keypad(stdscr,TRUE);
  meta(stdscr,TRUE);
  noecho();
  notimeout(stdscr,TRUE);
//  signal(SIGWINCH,CancellaSchermo);
}

void ChiusuraNCurses()
{
  endwin();
}

bool PremutoTasto()
{
  int c;
  
  nodelay(stdscr,TRUE);
  c = getch();
  nodelay(stdscr,FALSE);
  if (c == ERR)
    return(FALSE);
  ungetch(c);
  return(TRUE);
}

void Ritardo(int millisecondi)
{
  napms(millisecondi);
}

#define SEGMENTO1 8
#define SEGMENTO2 4
#define SEGMENTO3 2
#define SEGMENTO4 1

void SovraScriveCarattereYX(int y,int x, int carattere)
{
  int caratterePrecedente;
  int segmentiPrecedente,segmenti;

//  caratterePrecedente = mvinch(y,x);
  caratterePrecedente = LeggeCarattereYX(y,x);

  segmentiPrecedente = 0;
  if (caratterePrecedente == (ACS_ULCORNER & A_CHARTEXT))      segmentiPrecedente = SEGMENTO3|SEGMENTO4;
  else if (caratterePrecedente == (ACS_URCORNER & A_CHARTEXT)) segmentiPrecedente = SEGMENTO1|SEGMENTO4;
  else if (caratterePrecedente == (ACS_LLCORNER & A_CHARTEXT)) segmentiPrecedente = SEGMENTO2|SEGMENTO3;
  else if (caratterePrecedente == (ACS_LRCORNER & A_CHARTEXT)) segmentiPrecedente = SEGMENTO1|SEGMENTO2;
  else if (caratterePrecedente == (ACS_HLINE & A_CHARTEXT))    segmentiPrecedente = SEGMENTO1|SEGMENTO3;
  else if (caratterePrecedente == (ACS_VLINE & A_CHARTEXT))    segmentiPrecedente = SEGMENTO2|SEGMENTO4;
  else if (caratterePrecedente == (ACS_TTEE & A_CHARTEXT))     segmentiPrecedente = SEGMENTO1|SEGMENTO3|SEGMENTO4;
  else if (caratterePrecedente == (ACS_BTEE & A_CHARTEXT))     segmentiPrecedente = SEGMENTO1|SEGMENTO2|SEGMENTO3;
  else if (caratterePrecedente == (ACS_LTEE & A_CHARTEXT))     segmentiPrecedente = SEGMENTO2|SEGMENTO3|SEGMENTO4;
  else if (caratterePrecedente == (ACS_RTEE & A_CHARTEXT))     segmentiPrecedente = SEGMENTO1|SEGMENTO2|SEGMENTO4;
  else if (caratterePrecedente == (ACS_PLUS & A_CHARTEXT))     segmentiPrecedente = SEGMENTO1|SEGMENTO2|SEGMENTO3|SEGMENTO4;

  segmenti = 0;
  if (carattere == ACS_ULCORNER)      segmenti = SEGMENTO3|SEGMENTO4;
  else if (carattere == ACS_URCORNER) segmenti = SEGMENTO1|SEGMENTO4;
  else if (carattere == ACS_LLCORNER) segmenti = SEGMENTO2|SEGMENTO3;
  else if (carattere == ACS_LRCORNER) segmenti = SEGMENTO1|SEGMENTO2;
  else if (carattere == ACS_HLINE)    segmenti = SEGMENTO1|SEGMENTO3;
  else if (carattere == ACS_VLINE)    segmenti = SEGMENTO2|SEGMENTO4;
  else if (carattere == ACS_TTEE)     segmenti = SEGMENTO1|SEGMENTO3|SEGMENTO4;
  else if (carattere == ACS_BTEE)     segmenti = SEGMENTO1|SEGMENTO2|SEGMENTO3;
  else if (carattere == ACS_LTEE)     segmenti = SEGMENTO2|SEGMENTO3|SEGMENTO4;
  else if (carattere == ACS_RTEE)     segmenti = SEGMENTO1|SEGMENTO2|SEGMENTO4;
  else if (carattere == ACS_PLUS)     segmenti = SEGMENTO1|SEGMENTO2|SEGMENTO3|SEGMENTO4;

  if (segmenti != 0)
  {
    segmenti = segmenti | segmentiPrecedente;
    switch (segmenti)
    {
      case  0: carattere = ' ';          break; // 0000
      case  1: carattere = '*';          break; // 0001
      case  2: carattere = '*';          break; // 0010
      case  3: carattere = ACS_ULCORNER; break; // 0011
      case  4: carattere = '*';          break; // 0100
      case  5: carattere = ACS_VLINE;    break; // 0101
      case  6: carattere = ACS_LLCORNER; break; // 0110
      case  7: carattere = ACS_LTEE;     break; // 0111
      case  8: carattere = '*';          break; // 1000
      case  9: carattere = ACS_URCORNER; break; // 1001
      case 10: carattere = ACS_HLINE;    break; // 1010
      case 11: carattere = ACS_TTEE;     break; // 1011
      case 12: carattere = ACS_LRCORNER; break; // 1100
      case 13: carattere = ACS_RTEE;     break; // 1101
      case 14: carattere = ACS_BTEE;     break; // 1110
      case 15: carattere = ACS_PLUS;     break; // 1111
      default: ScriveCarattereYX(y,x,carattere); break;
    }
  }
  ScriveCarattereYX(y,x,carattere);
}

#undef SEGMENTO1
#undef SEGMENTO2
#undef SEGMENTO3
#undef SEGMENTO4

void TracciaRettangolo(int y1,int x1,int y2,int x2)
{
  int x,y;

  if (x1 > x2)
  {
    x = x1;
    x1 = x2;
    x2 = x;
    y = y1;
    y1 = y2;
    y2 = y;
  }
  if (y1 > y2)
    return;

  // Bordo superiore sinistro
  if (x1 != x2 && y1 != y2)
    SovraScriveCarattereYX(y1,x1,ACS_ULCORNER);
  else if (x1 != x2 && y1 == y2)
    SovraScriveCarattereYX(y1,x1,ACS_HLINE);
  else if (x1 == x2 && y1 != y2)
    SovraScriveCarattereYX(y1,x1,ACS_VLINE);
  else
    return;

  // traccia bordo superiore
  for (x=x1+1;x<x2;x++)
    SovraScriveCarattereYX(y1,x,ACS_HLINE);

  // Bordo superiore destro
  if (x1 != x2 && y1 != y2)
    SovraScriveCarattereYX(y1,x2,ACS_URCORNER);

  // traccia bordo sinistro
  for (y=y1+1;y<y2;y++)
    SovraScriveCarattereYX(y,x1,ACS_VLINE);

  // traccia bordo destro
  for (y=y1+1;y<y2;y++)
    SovraScriveCarattereYX(y,x2,ACS_VLINE);

  // Bordo inferiore sinistro
  if (x1 != x2 && y1 != y2)
    SovraScriveCarattereYX(y2,x1,ACS_LLCORNER);

  // traccia bordo inferiore
  for (x=x1+1;x<x2;x++)
    SovraScriveCarattereYX(y2,x,ACS_HLINE);

  // Bordo inferiore destro
  if (x1 != x2 && y1 != y2)
    SovraScriveCarattereYX(y2,x2,ACS_LRCORNER);

//  AggiornaSchermo();
}

void SpaziFinoAllaFine() // utilizza la riga del cursore
{
  int c,riga;

  LeggePosizioneCursore(riga,c);

  for (;c<COLS;c++)
    ScriveCarattereYX(riga,c,' ');
}

void CancellaRigaStato()
{
  CancellaLinea(LINES-1,COLS);
}

void ScriveCarattere7SegmentiYX(int riga,int colonna,char c) // c deve essere una cifra decimale (0-9)
{
  int i,j;

  for (i=0;i<5;i++)
    for (j=0;j<3;j++)
      ScriveCarattereYX(riga+i,colonna+j,' ');

  if (c < '0' && c > '9')
    return;

  // segmento A
  if (c == '0' || c == '2' || c == '3' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
    ScriveCarattereYX(riga,colonna+1,ACS_HLINE | A_BOLD);

  // segmento B
  if (c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '7' || c == '8' || c == '9')
    ScriveCarattereYX(riga+1,colonna+2,ACS_VLINE | A_BOLD);

  // segmento C
  if (c == '0' || c == '1' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
    ScriveCarattereYX(riga+3,colonna+2,ACS_VLINE | A_BOLD);

  // segmento D
  if (c == '0' || c == '2' || c == '3' || c == '5' || c == '6' || c == '8' || c == '9')
    ScriveCarattereYX(riga+4,colonna+1,ACS_HLINE | A_BOLD);

  // segmento E
  if (c == '0' || c == '2' || c == '6' || c == '8')
    ScriveCarattereYX(riga+3,colonna,ACS_VLINE | A_BOLD);

  // segmento F
  if (c == '0' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
    ScriveCarattereYX(riga+1,colonna,ACS_VLINE | A_BOLD);

  // segmento G
  if (c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '8' || c == '9')
    ScriveCarattereYX(riga+2,colonna+1,ACS_HLINE | A_BOLD);

}

void Scrive7SegmentiYX(int riga,int colonna,char c[]) // c è una sequenza di cifre decimali (0-9)
{
  int i;

  for (i=0;i<strlen(c);i++)
    ScriveCarattere7SegmentiYX(riga,colonna+3*i,c[i]);
}

void ScriveCarattereMaxiYX(int riga,int colonna,char c) // c deve essere una cifra decimale (0-9)
{
  int i,j;

  for (i=0;i<3;i++)
    for (j=0;j<3;j++)
      ScriveCarattereYX(riga+i,colonna+j,' ' | A_BOLD);

  if (c < '0' && c > '9')
    return;

  // segmento 1 superiore
  if (c == '0' || c == '2' || c == '3' || c == '4'|| c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
    ScriveCarattereYX(riga,colonna,ACS_ULCORNER | A_BOLD);

  // segmento 2 superiore
  if (c == '0' || c == '2' || c == '3' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9')
    ScriveCarattereYX(riga,colonna+1,ACS_HLINE | A_BOLD);

  // segmento 3 superiore
  ScriveCarattereYX(riga,colonna+2,ACS_URCORNER | A_BOLD);


  // segmento 1 centrale
  if (c == '0')
    ScriveCarattereYX(riga+1,colonna,ACS_VLINE | A_BOLD);
  if (c == '2')
    ScriveCarattereYX(riga+1,colonna,ACS_ULCORNER | A_BOLD);
  if (c == '4' || c == '5' || c == '9')
    ScriveCarattereYX(riga+1,colonna,ACS_LLCORNER | A_BOLD);
  if (c == '6' || c == '8')
    ScriveCarattereYX(riga+1,colonna,ACS_LTEE | A_BOLD);

  // segmento 2 centrale
  if (c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '8' || c == '9')
    ScriveCarattereYX(riga+1,colonna+1,ACS_HLINE | A_BOLD);

  // segmento 3 centrale
  if (c == '0' || c == '1' || c == '7')
    ScriveCarattereYX(riga+1,colonna+2,ACS_VLINE | A_BOLD);
  if (c == '2')
    ScriveCarattereYX(riga+1,colonna+2,ACS_LRCORNER | A_BOLD);
  if (c == '3' || c == '4' || c == '8' || c == '9')
    ScriveCarattereYX(riga+1,colonna+2,ACS_RTEE | A_BOLD);
  if (c == '5' || c == '6')
    ScriveCarattereYX(riga+1,colonna+2,ACS_URCORNER | A_BOLD);


  // segmento 1 inferiore
  if (c == '0' || c == '2' || c == '3' || c == '5' || c == '6' || c == '8' || c == '9')
    ScriveCarattereYX(riga+2,colonna,ACS_LLCORNER | A_BOLD);

  // segmento 2 inferiore
  if (c == '0' || c == '2' || c == '3' || c == '5' || c == '6' || c == '8' || c == '9')
    ScriveCarattereYX(riga+2,colonna+1,ACS_HLINE | A_BOLD);

  // segmento 3 inferiore
  if (c == '0' || c == '2' || c == '3' || c == '5' || c == '6' || c == '8' || c == '9')
    ScriveCarattereYX(riga+2,colonna+2,ACS_LRCORNER | A_BOLD);
  if (c == '1' || c == '4' || c == '7')
    ScriveCarattereYX(riga+2,colonna+2,ACS_BTEE | A_BOLD);
}

void ScriveMaxiYX(int riga,int colonna,char c[]) // c è una sequenza di cifre decimali (0-9)
{
  int i;

  for (i=0;i<strlen(c);i++)
    ScriveCarattereMaxiYX(riga,colonna+3*i,c[i]);
}

void CaricaMappa(char nomefile[])
{
  FILE *f;
  int r,c;
  int car,attr;

  if ((f = fopen(nomefile,"rb")) != NULL)
  {
    for (r=0;r<LINES;r++)
    {
      for (c=0;c<COLS;c++)
      {
        fread(&car,sizeof(car),1,f);
        fread(&attr,sizeof(attr),1,f);       
        ScriveCarattereYX(r,c,car|attr);
      }
    }
    AggiornaSchermo();
    fclose(f);
  }
}

void SalvaMappa(char nomefile[])
{
  FILE *f;
  int r,c;
  int car,attr;

  if ((f = fopen(nomefile,"wb")) != NULL)
  {
    for (r=0;r<LINES;r++)
    {
      for (c=0;c<COLS;c++)
      {
        car = LeggeCarattereYX(r,c);
        attr = LeggeAttributoYX(r,c);
        fwrite(&car,sizeof(car),1,f);
        fwrite(&attr,sizeof(attr),1,f);
      }
    }
    fclose(f);
  }
}

void strupr(char s[])
{
  int i;

  for (i=0;i<strlen(s);i++)
    if (islower(s[i]))
      s[i] = toupper(s[i]);
}

void AttendePressioneTasto(int carattere)
{
  do
  {
  }
  while (LeggeCarattereDaTastiera() != carattere);
}

void NascondeColonna(int colonna)
{
  int i;

  for (i=0;i<LINES;i++)
    ScriveCarattereYX(i,colonna,mvinch(i,colonna)|A_INVIS);
  AggiornaSchermo();
}

void ScopreColonna(int colonna)
{
  int i;

  for (i=0;i<LINES;i++)
    ScriveCarattereYX(i,colonna,mvinch(i,colonna) & (~A_INVIS));
  AggiornaSchermo();
}

void NascondeRiga(int riga)
{
  int i;

  for (i=0;i<COLS;i++)
    ScriveCarattereYX(riga,i,mvinch(riga,i)|A_INVIS);
  AggiornaSchermo();
}

void ScopreRiga(int riga)
{
  int i;

  for (i=0;i<COLS;i++)
    ScriveCarattereYX(riga,i,mvinch(riga,i) & (~A_INVIS));
  AggiornaSchermo();
}

/***********************************************************/
/*   LIBRERIA DI SEMPLIFICAZIONE PER L'USO DELLE NCURSES   */
/*   Versione 4.0                                          */	
/*   Aggiornamento al 2 aprile 2011                        */
/***********************************************************/
// FINE FILE DI INCLUDE ACCESSONCURSES4.H

