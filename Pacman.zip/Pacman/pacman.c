#include "accessoNCurses4.h"

#define TAB       9
#define RETURN    13
#define ESC       27
#define SOTTO     258
#define SOPRA     259
#define SINISTRA  260
#define DESTRA    261
#define HOME      262
#define F2        266
#define F12       276
#define CANC      330
#define PAGINAGIU 338
#define PAGINASU  339
#define FINE      360

#define PUNTO	  ACS_BULLET

#define PACMAN_CHIUSO   ('0'|A_BOLD)
#define PACMAN_APERTO   ('C'|A_BOLD)

#define FANTASMA_CHIUSO ('A'|A_BOLD)
#define FANTASMA_APERTO (ACS_UARROW|A_BOLD)

#define NUMERO_RIGHE   31
#define NUMERO_COLONNE 80

#define RIGAMIN   	3
#define RIGAMAX   	29
#define COLONNAMIN	1
#define COLONNAMAX	51

#define MAX_FANTASMI	1

//#define PUNTEGGIOMAX 2860

int riga,colonna;	// posizione di PACMAN
int rigaInizio,colonnaInizio;
int punti;
int punto;
int carattere;
bool inizio;
bool visualizzaCodiceTasto;
bool minipacman;
bool fine;
int contatore;
int pacman;
int fantasma[4];

int fantasmaR[4];	// riga fantasma i-esimo
int fantasmaC[4];	// colonna fantasma i-esimo
int vecchioCarattere[4];	// memorizza, per ogni fantasma, il carattere originario della posizione corrente
int vecchioAttributo[4];	// memorizza, per ogni fantasma, l'attributo originario della posizione corrente
int dR[4];		// ultimo spostamento di riga fantasma i-esimo
int dC[4];		// ultimo spostamento di colonna fantasma i-esimo

int punteggioMax;

int ch;			// ultimo carattere letto dalla tastiera


void IncrementaPunteggio()
{
  punti += 10;
}

void VisualizzaPunteggio()
{
  char s[10];

  if (minipacman)
  {
//    ScriveYX(1,0,"%7d",contatore);
    AttivaGrassetto();
    ImpostaColoreTesto(COLOR_YELLOW);
    sprintf(s,"%04d",punti);
    ScriveMaxiYX(5,61,s);
    AnnullaImpostazioneColoreTesto(COLOR_YELLOW);
//    Scrive7SegmentiYX(4,58,s);
    ImpostaColoreTesto(COLOR_GREEN);
    ScriveYX(1,28,"%-4d",punti);
    AnnullaImpostazioneColoreTesto(COLOR_GREEN);
    DisattivaGrassetto();
  }
}

void MuovePacMan(int deltaX,int deltaY)
{
  ImpostaColoreTesto(COLOR_RED);
  if ((deltaY > 0 && riga < LINES-1) ||
      (deltaY < 0 && riga > 0) ||
      (deltaX > 0 && ((colonna < COLS-1 && !minipacman) || (colonna < 52 && minipacman))) || (deltaX < 0 && colonna > 0))
  {
    carattere = LeggeCarattereYX(riga+deltaY,colonna+deltaX);
//    fprintf(stderr,"carattere[%d][%d]: %d\n",riga+deltaY,colonna+deltaX,carattere);
    if (minipacman == FALSE ||
       (minipacman && ((carattere == ' ') || (carattere == punto))))
    {
      colonna += deltaX;
      riga += deltaY;
      if (minipacman)
      {
        if (carattere == punto)
          IncrementaPunteggio();
        ScriveCarattereYX(riga-deltaY,colonna-deltaX,' ');
        AttivaGrassetto();
        ScriveCarattereYX(riga,colonna,pacman);
        DisattivaGrassetto();
        if (punti >= punteggioMax)
        {
          VisualizzaPunteggio();
          AttivaGrassetto();
          ScriveYX(14,55,"                        ");
          ScriveYX(15,55,"                        ");
          ScriveYX(16,55,"                        ");
          ScriveYX(17,55,"                        ");
          ImpostaColoreTesto(COLOR_RED);
          ScriveYX(18,55,"        LIVELLO         ");
          ScriveYX(19,55,"        CONCLUSO        ");
          ScriveYX(22,55,"  Premere il tasto ESC  ");
          ScriveYX(23,55,"       per uscire       ");
          AnnullaImpostazioneColoreTesto(COLOR_RED);
          DisattivaGrassetto();
          fine = TRUE;
          AttendePressioneTasto(ESC);
        }
      }
    }
  }
  else if (deltaX > 0 && colonna == 52 && LeggeCarattereYX(riga,0) == ' ' && minipacman)
  {
    ScriveCarattereYX(riga,colonna,' ');
    AttivaGrassetto();
    colonna = 0;
    ScriveCarattereYX(riga,colonna,pacman);
    DisattivaGrassetto();
  }
  else if (deltaX < 0 && colonna == 0 && LeggeCarattereYX(riga,52) == ' ' && minipacman)
  {
    ScriveCarattereYX(riga,colonna,' ');
    AttivaGrassetto();
    colonna = 52;
    ScriveCarattereYX(riga,colonna,pacman);
    DisattivaGrassetto();
  }
  AnnullaImpostazioneColoreTesto(COLOR_RED);
}

void VisualizzaIstruzioni()
{
  AttivaGrassetto();
  ImpostaColoreTesto(COLOR_GREEN);
  TracciaRettangolo(2,54,10,79);
  AnnullaImpostazioneColoreTesto(COLOR_GREEN);
  ImpostaColoreTesto(COLOR_YELLOW);
  TracciaRettangolo(4,59,8,74);
  TracciaRettangolo(12,54,30,79);	// RIQUADRO DI AIUTO
  ScriveYX(19,55," Premere ESC per uscire ");
  ScriveYX(22,55," Spostare  PACMAN con i ");
  ScriveYX(23,55,"   tasti di direzione   ");
  AnnullaImpostazioneColoreTesto(COLOR_YELLOW);
  DisattivaGrassetto();
}

void VisualizzaCodiceTasto(int ch)
{
  ScriveYX(LINES-1,0,"CODICE DEL TASTO: %7d",ch);
}

void InizializzazionePacMan()
{
  int i;

  riga = 3;
  colonna = 2;
  pacman = PACMAN_APERTO;
  for (i=0;i<MAX_FANTASMI;i++)
    fantasma[i] = FANTASMA_CHIUSO;
  for (i=0;i<MAX_FANTASMI;i++)
  {
    vecchioCarattere[i] = 0;
    vecchioAttributo[i] = 0;
  }

/*
  fantasmaR[0] = 3;
  fantasmaC[0] = 22;
  fantasmaR[1] = 0;
  fantasmaC[1] = 0;
  fantasmaR[2] = 0;
  fantasmaC[2] = 0;
  fantasmaR[3] = 0;
  fantasmaC[3] = 0;
*/

  for (i=0;i<MAX_FANTASMI;i++)
  {
    dR[i] = 0;
    dC[i] = 0;
  }

  fantasmaR[0] = 15;
  fantasmaC[0] = 23;

  fantasmaR[1] = 15;
  fantasmaC[1] = 25;

  fantasmaR[2] = 15;
  fantasmaC[2] = 27;

  fantasmaR[3] = 15;
  fantasmaC[3] = 29;

  for (i=MAX_FANTASMI;i<4;i++)
  {
    fantasmaR[i] = 0;
    fantasmaC[i] = 0;
  }

  visualizzaCodiceTasto = false;
  minipacman = false;
  inizio = FALSE;
  fine = FALSE;
  punti = 0;
  contatore = 0;
  ch = 0;
}

void VisualizzaSfondo()
{
  int mezzoX,mezzoY,quartoX,quartoY;
  int i,y;

  mezzoX = COLS / 2;
  mezzoY = LINES / 2;
  quartoX = COLS / 4;
  quartoY = LINES / 4;

  AttivaGrassetto();
  ImpostaColoreTesto(COLOR_WHITE);
  ScriveYX(0,0,"     T O P        H I G H   S C O R E");
  AnnullaImpostazioneColoreTesto(COLOR_WHITE);

  ImpostaColoreTesto(COLOR_YELLOW);
  for (i=1;i<=51;i+=2)
  {
    ScriveCarattereYX(3,i,PUNTO);
    ScriveCarattereYX(7,i,PUNTO);
    ScriveCarattereYX(10,i,PUNTO);
    ScriveCarattereYX(20,i,PUNTO);
    ScriveCarattereYX(23,i,PUNTO);
    ScriveCarattereYX(26,i,PUNTO);
    ScriveCarattereYX(29,i,PUNTO);
  }

  for (i=1;i<=17;i+=2)
  {
    ScriveCarattereYX(15,i,PUNTO);
    ScriveCarattereYX(15,i+34,PUNTO);
  }

  for (i=17;i<=35;i+=2)
  {
    ScriveCarattereYX(13,i,PUNTO);
    ScriveCarattereYX(17,i,PUNTO);
  }

  for (i=2;i<=29;i++)
  {
    ScriveCarattereYX(i,1,PUNTO);
    ScriveCarattereYX(i,11,PUNTO);
    ScriveCarattereYX(i,17,PUNTO);
    ScriveCarattereYX(i,23,PUNTO);
    ScriveCarattereYX(i,29,PUNTO);
    ScriveCarattereYX(i,35,PUNTO);
    ScriveCarattereYX(i,41,PUNTO);
    ScriveCarattereYX(i,51,PUNTO);
  }

  ScriveCarattereYX(24,05,PUNTO);
  ScriveCarattereYX(25,05,PUNTO);

  ScriveCarattereYX(24,47,PUNTO);
  ScriveCarattereYX(25,47,PUNTO);

  AnnullaImpostazioneColoreTesto(COLOR_YELLOW);

  ImpostaColoreTesto(COLOR_BLUE);
  TracciaRettangolo(2,0,30,52);		// CORNICE PRINCIPALE

  TracciaRettangolo(4,2,6,10);		// CORNICE SINISTRA SUPERIORE ESTERNA
  TracciaRettangolo(4,12,6,22);		// CORNICE SINISTRA SUPERIORE CENTRALE
  TracciaRettangolo(2,24,6,28);		// CORNICE CENTRALE SUPERIORE
  TracciaRettangolo(4,30,6,40);		// CORNICE DESTRA SUPERIORE CENTRALE
  TracciaRettangolo(4,42,6,50);		// CORNICE DESTRA SUPERIORE ESTERNA

  TracciaRettangolo(8,2,9,10);		//
  TracciaRettangolo(8,12,14,16);	//
  TracciaRettangolo(11,16,12,22);	//

  TracciaRettangolo(8,18,9,34);		// CORNICE INTERNA SUPERIORE A T (parte superiore)
  TracciaRettangolo(9,24,12,28);	// CORNICE INTERNA SUPERIORE A T (parte inferiore)

  TracciaRettangolo(8,36,14,40);	//
  TracciaRettangolo(11,30,12,36);	//
  TracciaRettangolo(8,42,9,50);		//

  TracciaRettangolo(11,0,14,10);	//
  TracciaRettangolo(11,42,14,52);	//

  TracciaRettangolo(16,0,19,10);	//
  TracciaRettangolo(16,42,19,52);	//

  TracciaRettangolo(16,12,19,16);	//
  TracciaRettangolo(16,36,19,40);	//

  TracciaRettangolo(18,18,19,34);	// CORNICE INTERNA CENTRALE A T (parte superiore)
  TracciaRettangolo(19,24,22,28);	// CORNICE INTERNA CENTRALE A T (parte inferiore)

  TracciaRettangolo(21,2,22,10);	// CORNICE A L ROVESCIATA SINISTRA (parte superiore)
  TracciaRettangolo(22,6,25,10);	// CORNICE A L ROVESCIATA SINISTRA (parte inferiore)

  TracciaRettangolo(21,42,22,50);	// CORNICE A L ROVESCIATA DESTRA (parte superiore)
  TracciaRettangolo(22,42,25,46);	// CORNICE A L ROVESCIATA DESTRA (parte inferiore)

  TracciaRettangolo(21,12,22,22);	//
  TracciaRettangolo(21,30,22,40);	//

  TracciaRettangolo(27,2,28,22);	// CORNICE INFERIORE A T ROVESCIATA SX (parte inferiore)
  TracciaRettangolo(24,12,27,16);	// CORNICE INFERIORE A T ROVESCIATA SX (parte superiore)

  TracciaRettangolo(27,30,28,50);	// CORNICE INFERIORE A T ROVESCIATA DX (parte inferiore)
  TracciaRettangolo(24,36,27,40);	// CORNICE INFERIORE A T ROVESCIATA DX (parte superiore)

  TracciaRettangolo(24,0,25,4);		//
  TracciaRettangolo(24,48,25,52);	//

  TracciaRettangolo(24,18,25,34);	// CORNICE INTERNA INFERIORE A T (parte superiore)
  TracciaRettangolo(25,24,28,28);	// CORNICE INTERNA INFERIORE A T (parte inferiore)

  TracciaRettangolo(14,18,16,34);	// GABBIA DEI FANTASMI

  ScriveCarattereYX(5,17,' ');	//
  ScriveCarattereYX(5,35,' ');	//
  ScriveCarattereYX(3,25,' ');	//
  ScriveCarattereYX(3,27,' ');	//
  ScriveCarattereYX(10,13,' ');	//
  ScriveCarattereYX(10,15,' ');	//

  ScriveCarattereYX(10,25,' ');	//
  ScriveCarattereYX(10,27,' ');	//
  ScriveCarattereYX(20,25,' ');	//
  ScriveCarattereYX(20,27,' ');	//
  ScriveCarattereYX(26,25,' ');	//
  ScriveCarattereYX(26,27,' ');	//

  ScriveCarattereYX(10,37,' ');	//
  ScriveCarattereYX(10,39,' ');	//
  ScriveCarattereYX(12,1,' ');	//
  ScriveCarattereYX(12,51,' ');	//
  ScriveCarattereYX(13,1,' ');	//
  ScriveCarattereYX(13,51,' ');	//
  ScriveCarattereYX(15,23,' ');	//
  ScriveCarattereYX(15,29,' ');	//

  ScriveCarattereYX(17,1,' ');	//
  ScriveCarattereYX(18,1,' ');	//

  ScriveCarattereYX(17,51,' ');	//
  ScriveCarattereYX(18,51,' ');	//

  ScriveCarattereYX(15,0,' ');	//
  ScriveCarattereYX(15,52,' ');	//

  ScriveCarattereYX(23,7,' ');	//
  ScriveCarattereYX(23,9,' ');	//

  ScriveCarattereYX(23,43,' ');	//
  ScriveCarattereYX(23,45,' ');	//

  ScriveCarattereYX(26,13,' ');	//
  ScriveCarattereYX(26,15,' ');	//

  ScriveCarattereYX(26,37,' ');	//
  ScriveCarattereYX(26,39,' ');	//

  ScriveCarattereYX(2,24,ACS_TTEE);	//
  ScriveCarattereYX(2,28,ACS_TTEE);	//

  for (i=0;i<=10;i+=10)
  {
    ScriveCarattereYX(9+i,24,ACS_URCORNER);//
    ScriveCarattereYX(9+i,25,' ');//
    ScriveCarattereYX(9+i,26,' ');//
    ScriveCarattereYX(9+i,27,' ');//
    ScriveCarattereYX(9+i,28,ACS_ULCORNER);//
  }

  ScriveCarattereYX(22,6,ACS_URCORNER);//
  ScriveCarattereYX(22,7,' ');//
  ScriveCarattereYX(22,8,' ');//
  ScriveCarattereYX(22,9,' ');//
  ScriveCarattereYX(22,10,ACS_VLINE);//

  ScriveCarattereYX(22,42,ACS_VLINE);//
  ScriveCarattereYX(22,43,' ');//
  ScriveCarattereYX(22,44,' ');//
  ScriveCarattereYX(22,45,' ');//
  ScriveCarattereYX(22,46,ACS_ULCORNER);//

  ScriveCarattereYX(25,24,ACS_URCORNER);//
  ScriveCarattereYX(25,25,' ');//
  ScriveCarattereYX(25,26,' ');//
  ScriveCarattereYX(25,27,' ');//
  ScriveCarattereYX(25,28,ACS_ULCORNER);//

  ScriveCarattereYX(27,12,ACS_LRCORNER);//
  ScriveCarattereYX(27,13,' ');//
  ScriveCarattereYX(27,14,' ');//
  ScriveCarattereYX(27,15,' ');//
  ScriveCarattereYX(27,16,ACS_LLCORNER);//

  ScriveCarattereYX(27,36,ACS_LRCORNER);//
  ScriveCarattereYX(27,37,' ');//
  ScriveCarattereYX(27,38,' ');//
  ScriveCarattereYX(27,39,' ');//
  ScriveCarattereYX(27,40,ACS_LLCORNER);//

  ScriveCarattereYX(11,0,ACS_LTEE);	//
  ScriveCarattereYX(19,0,ACS_LTEE);	//
  ScriveCarattereYX(24,0,ACS_LTEE);	//
  ScriveCarattereYX(25,0,ACS_LTEE);	//

  ScriveCarattereYX(11,52,ACS_RTEE);	//
  ScriveCarattereYX(19,52,ACS_RTEE);	//
  ScriveCarattereYX(24,52,ACS_RTEE);	//
  ScriveCarattereYX(25,52,ACS_RTEE);	//

  ScriveCarattereYX(11,16,ACS_LLCORNER);//
  ScriveCarattereYX(12,16,ACS_ULCORNER);//
  ScriveCarattereYX(11,36,ACS_LRCORNER);//
  ScriveCarattereYX(12,36,ACS_URCORNER);//

  ScriveCarattereYX(14,24,' ');	//
  ScriveCarattereYX(14,25,' ');	//
  ScriveCarattereYX(14,26,' ');	//
  ScriveCarattereYX(14,27,' ');	//
  ScriveCarattereYX(14,28,' ');	//

  AnnullaImpostazioneColoreTesto(COLOR_BLUE);
  DisattivaGrassetto();
}

void RilevaPunteggioMax() 
{
  int r,c;
  int car;

  punteggioMax = 0;
  punto = LeggeCarattereYX(3,1);
  for (r=0;r<LINES;r++)
  {
    for (c=0;c<COLS;c++)
    {
      car = LeggeCarattereYX(r,c);
//      fprintf(stderr,"car[%d][%d]: %d\n",r,c,car);
      if (car == punto)
      {
        punteggioMax += 10;
//        fprintf(stderr,"punteggioMax: %d\n",punteggioMax);
      }
    }
  }
}

void VisualizzaPacman()
{
  ImpostaColoreTesto(COLOR_RED);
  ScriveCarattereYX(riga,colonna,pacman);
  AnnullaImpostazioneColoreTesto(COLOR_RED);
}

void VisualizzaFantasmi()
{
  int i;
  int colore[] = { COLOR_GREEN,COLOR_BLUE,COLOR_MAGENTA,COLOR_CYAN };

  for (i=0;i<MAX_FANTASMI;i++)
  {
    if (vecchioCarattere[i] == 0)
    {
      vecchioCarattere[i] = LeggeCarattereYX(fantasmaR[i],fantasmaC[i]);
      vecchioAttributo[i] = LeggeAttributoYX(fantasmaR[i],fantasmaC[i]);
    }
  }

  for (i=0;i<MAX_FANTASMI;i++)
  {
    ImpostaColoreTesto(colore[i]);
    ScriveCarattereYX(fantasmaR[i],fantasmaC[i],fantasma[i]);
    AnnullaImpostazioneColoreTesto(colore[i]);
  }
}

int DistanzaFantasmaDaPacMan(int i)
{
  int distanza;

  distanza = abs(fantasmaR[i]-riga)+abs(fantasmaC[i]-colonna);
  fprintf(stderr,"DISTANZA FANTASMA%d DA PACMAN: %d [fantasmaR=%d fantasmaC=%d][riga=%d colonna=%d]\n",i,distanza,fantasmaR[i],fantasmaC[i],riga,colonna);
  return (distanza);
}

bool MuoveFantasma(int i,int dr,int dc)
{
  int carattereNuovaPosizione;
  int attributoNuovaPosizione;
  int j;
  int vecchiaR,vecchiaC;

  // memorizza la posizione corrente del fantasma per ripristinarla nel caso di impossibilità di movimento
  vecchiaR = fantasmaR[i];
  vecchiaC = fantasmaC[i];
  fprintf(stderr,"fantasma[%d] vecchiaR=%d vecchiaC=%d\n",i,vecchiaR,vecchiaC);

  // effettua lo spostamento come comandato
  fantasmaR[i] += dr;
  fantasmaC[i] += dc;
  fprintf(stderr,"fantasma[%d] NUOVA POSIZIONE? riga=%d colonna=%d\n",i,fantasmaR[i],fantasmaC[i]);

  // se la nuova posizione non è regolare ripristina la vecchia posizione
  if (fantasmaR[i] < RIGAMIN || fantasmaR[i] > RIGAMAX || fantasmaC[i] < COLONNAMIN || fantasmaC[i] > COLONNAMAX)
  {
    fantasmaR[i] = vecchiaR;
    fantasmaC[i] = vecchiaC;
    fprintf(stderr,"fantasma[%d] NUOVA POSIZIONE SCARTATA PERCHE' FUORI INTERVALLO\n",i);
    return(FALSE);
  }
  carattereNuovaPosizione = LeggeCarattereYX(fantasmaR[i],fantasmaC[i]);
  attributoNuovaPosizione = LeggeAttributoYX(fantasmaR[i],fantasmaC[i]);

  if (carattereNuovaPosizione == pacman)
  {
    fine = TRUE;
    return(TRUE);
  }

  if (carattereNuovaPosizione != ' ' && carattereNuovaPosizione != punto)
  {
    fantasmaR[i] = vecchiaR;
    fantasmaC[i] = vecchiaC;
    fprintf(stderr,"fantasma[%d] NUOVA POSIZIONE SCARTATA PERCHE' OCCUPATA DAL CARATTERE %c [codice %d]\n",i,carattereNuovaPosizione,carattereNuovaPosizione);
    return(FALSE);
  }
  
  for (j=0;j<4;j++)
  {
    if (i != j && fantasmaR[i] == fantasmaR[j] && fantasmaC[i] == fantasmaC[j])
    {
      fantasmaR[i] = vecchiaR;
      fantasmaC[i] = vecchiaC;
      fprintf(stderr,"fantasma[%d] NUOVA POSIZIONE SCARTATA PERCHE' OCCUPATA DAL FANTASMA %d\n",i,j);
      return(FALSE);
    }
  }
  
  fprintf(stderr,"fantasma[%d] VECCHIA POSIZIONE CANCELLATA riga=%d colonna=%d\n",i,vecchiaR,vecchiaC);
  if (vecchioCarattere[i] != 0)
    ScriveCarattereYX(vecchiaR,vecchiaC,vecchioCarattere[i]|vecchioAttributo[i]);
  vecchioCarattere[i] = carattereNuovaPosizione;
  vecchioAttributo[i] = attributoNuovaPosizione;
  fprintf(stderr,"fantasma[%d] CONFERMATA NUOVA POSIZIONE riga=%d colonna=%d\n",i,fantasmaR[i],fantasmaC[i]);
  dR[i] = dr;
  dC[i] = dc;
  return(TRUE);
}

void SpostaFantasmi()
{
  int i;
  int dr,dc;

  for (i=0;i<MAX_FANTASMI;i++)
  {
    if (DistanzaFantasmaDaPacMan(i) <= 1)
    {
      // PacMan è fritto!!!
      fprintf(stderr,"fantasma[%d] SI MANGIA PACMAN\n",i);
      fine = TRUE;
      return;
    }
    if (dR[i] != 0 || dC[i] != 0) // usa l'ultima direzione se è stata fruttuosa
    {  
      dr = dR[i];
      dr = dC[i];
      fprintf(stderr,"fantasma[%d] USA VECCHIA DIREZIONE dr=%d dc=%d\n",i,dr,dc);
      // prova quattro direzioni in ordine
      if (!MuoveFantasma(i,dr,dc))
      {
        // questa direzione crea problemi: la si memorizza per evitarla in futuro
        dR[i] = -dr;
        dC[i] = -dc;
        if (!MuoveFantasma(i,dc,dr))
          if (!MuoveFantasma(i,-dc,-dr))
          {
            if (!MuoveFantasma(i,-dr,-dc)) ; // lascia per ultima alternativa lo spostamento che AUMENTA la distanza da PACMAN
              else
            fprintf(stderr,"*** fantasma[%d] ALGORITMO A.I. IN TILT! dR=%d dC=%d\n",i,-dr,-dc);
          }
      }
    }
    else
    {  
      // trova la direzione ottimale per raggiungere PACMAN
      dr = (riga != fantasmaR[i]) ? -(riga-fantasmaR[i])/abs(riga-fantasmaR[i]) : +1;
      if (dr == 0)
        dc = (colonna != fantasmaC[i]) ? -(colonna-fantasmaC[i])/abs(colonna-fantasmaC[i]) : +1;
      else
        dc = 0;
      fprintf(stderr,"fantasma[%d] DIREZIONE OTTIMALE dr=%d dc=%d\n",i,dr,dc);

      // prova quattro direzioni in ordine
      if (MuoveFantasma(i,-dr,-dc))
      {
        // ha trovato una buona direzione: cerca di utilizzarla in futuro
        dR[i] = dr;
        dC[i] = dc;
      }
      else
        if (!MuoveFantasma(i,dc,dr))
          if (!MuoveFantasma(i,-dc,-dr))
          {
            if (!MuoveFantasma(i,dr,dc)) ; // lascia per ultima alternativa l'ultimo spostamento
              else
            fprintf(stderr,"*** fantasma[%d] ALGORITMO A.I. IN TILT! dR=%d dC=%d\n",i,dR[i],dC[i]);
          }
    }
  }
}

int main()
{
  int i;
  int niente;

  InizializzazioneNCurses();
  if ((LINES >= NUMERO_RIGHE) && (COLS >= NUMERO_COLONNE))
  {
    DisattivaCursore();
    InizializzazionePacMan();
    VisualizzaIstruzioni();
    VisualizzaSfondo();
    RilevaPunteggioMax();

    minipacman = !minipacman;
    do
    {
      SpostaCursore(riga,colonna);
      VisualizzaPacman();
      VisualizzaFantasmi();
      VisualizzaPunteggio();
      AggiornaSchermo();

      if (minipacman)
      {
        contatore++;
        if ((contatore % 3) == 0)
        {
          pacman = (pacman == PACMAN_CHIUSO) ? PACMAN_APERTO : PACMAN_CHIUSO;
          for (i=0;i<MAX_FANTASMI;i++)
            fantasma[i] = (fantasma[i] == FANTASMA_CHIUSO) ? FANTASMA_APERTO : FANTASMA_CHIUSO;
        }
      }

      if (PremutoTasto() || minipacman == FALSE)
      {
        if (minipacman)
          inizio = TRUE;
        ch = LeggeCarattereDaTastiera();
        if (minipacman)
        {
          while (PremutoTasto())
            niente = LeggeCarattereDaTastiera();
        }
      }
/*
        if (visualizzaCodiceTasto)
          VisualizzaCodiceTasto(ch);
*/
        if (ch == SOTTO)
          MuovePacMan(0,+1);
        else if (ch == SOPRA)
          MuovePacMan(0,-1);
        else if (ch == SINISTRA)
          MuovePacMan(-1,0);
        else if (ch == DESTRA)
          MuovePacMan(+1,0);
        else if (ch == ESC)
          fine = TRUE;

/*
        else if (ch == CANC)
          erase();
        else if (ch == TAB)
          visualizzaCodiceTasto = true;
        else if (ch == F12)
        {
          minipacman = !minipacman;
          if (minipacman)
            VisualizzaPacman();
          else
            ScriveCarattereYX(riga,colonna,' ');
        }
        else if (ch == RETURN)
        {
          ch = LeggeCarattereYX(riga,colonna);
          VisualizzaCodiceTasto(ch);
          ScriveYX(31,26,"RIGA=%02d COLONNA=%02d",riga,colonna);
        }
        else if (ch == F2)
        {
          ch = LeggeAttributoYX(riga,colonna);
          VisualizzaCodiceTasto(ch);
        }
        else if (ch == HOME && !minipacman)
        {
          riga = 0;
          colonna = 0;
        }
        else if (toupper(ch) == 'L')
          CaricaMappa("mappa.bin");
        else if (toupper(ch) == 'S')
          SalvaMappa("mappa.bin");
        else if (ch == FINE && !minipacman)
        {
          riga = LINES-1;
          colonna = COLS-1;
        }
        else if (ch == PAGINAGIU && !minipacman)
          riga = LINES-1;
        else if (ch == PAGINASU && !minipacman)
          riga = 0;
        else if (ch == '7')
          LeggePosizioneCursore(rigaInizio,colonnaInizio);
        else if (ch == '3')
          TracciaRettangolo(rigaInizio,colonnaInizio,riga,colonna);
        else if (ch == ' ' || ch == PUNTO)
        {
          ScriveCarattereYX(riga,colonna,ch);
          if (colonna < COLS-1)
            colonna++;
        }
*/
/*
      else if (minipacman)
        contatore++;
*/

      if (minipacman)
      {
        if (ch == SINISTRA || ch == DESTRA)
          Ritardo(75);
        else
          Ritardo(125);
      }
      if (minipacman && inizio && (contatore % 2) == 1)
      {
//	SpostaFantasmi();
//	SpostaFantasmi();
      }
    }
    while (fine == FALSE);
  }
  else
  {
    AttivaGrassetto();
    Scrive("E' necessario predisporre almeno %d righe e %d colonne\n",NUMERO_RIGHE,NUMERO_COLONNE);
    DisattivaGrassetto();
    while (PremutoTasto() == FALSE) ;
  }
  AttivaCursore();
  ChiusuraNCurses();
  return(0);
}

