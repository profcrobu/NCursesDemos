#include "accessoNCurses5.h"
#include <ctype.h>
#include <stdlib.h>
#include <time.h>

//#define DEBUG

#define INVIO	 13
#define ESC	 27
#define GIU	 258
#define SU	 259
#define SINISTRA 260
#define DESTRA	 261

#define NR 10
#define NC 12

// Numero massimo di righe:   10
// Numero massimo di colonne: 12
// OPPURE un'altra combinazione di valori che dia un prodotto PARI inferiore o uguale a 120

#define RIGA_INIZIALE		1
#define COLONNA_INIZIALE	3
#define RIGA_FINALE		RIGA_INIZIALE+2*(NR-1)
#define COLONNA_FINALE		COLONNA_INIZIALE+4*(NC-1)

typedef int MEMORY[NR][NC];

MEMORY memory;
int nr;			// n.ro di righe EFFETTIVE
int nc;			// n.ro di colonne EFFETTIVE

int indicePrimo;	// indice della prima tessera scoperta
int indiceSecondo;	// indice della seconda tessera scoperta
int stato;		// = 1 significa che la prima tessera è già stata scoperta
int mancanti;		// n.ro di tessere ancora scoperte (mancanti)
int mosse;

int carattere;		// tasto di comando del gioco

void GeneraSchema(MEMORY memory,int nr,int nc)
{
  int i,j,k,indice;
    	
#ifdef DEBUG
  fprintf(stderr,"GeneraSchema - nr: %d\n",nr);
  fprintf(stderr,"GeneraSchema - nc: %d\n",nc);
#endif
  k = 2;
  for (i=0;i<nr;i++)
    for (j=0;j<nc;j++)
    {
      indice = i*NC+j;
      memory[i][j] = -(k++/2); // tutte le tessere sono coperte
#ifdef DEBUG
      fprintf(stderr,"GeneraSchema - memory[%d][%d]: %d\n",i,j,memory[i][j]);
#endif
    }
}

void MischiaSchema(MEMORY memory,int nr,int nc)
{
  int i1,j1,i2,j2,k,n,primo,secondo,temp;
    	
#ifdef DEBUG
  fprintf(stderr,"MischiaSchema - nr: %d\n",nr);
  fprintf(stderr,"MischiaSchema - nc: %d\n",nc);
#endif
  srand(time(0));
  n = nr*nc;
  for (k=0;k<n*n;k++)
  {
    primo = rand()%n;
    secondo = rand()%n;
    i1 = primo/nc;
    j1 = primo%nc;
    i2 = secondo/nc;
    j2 = secondo%nc;
    if (primo != secondo && primo >= 0 && primo < n && secondo >= 0 && secondo < n)
    {
      temp = memory[i1][j1];
      memory[i1][j1] = memory[i2][j2];
      memory[i2][j2] = temp;
#ifdef DEBUG
      fprintf(stderr,"MischiaSchema - memory[%d][%d]: %d\n",i1,j1,memory[i1][j1]);
      fprintf(stderr,"MischiaSchema - memory[%d][%d]: %d\n",i2,j2,memory[i2][j2]);
#endif
    }
  }
}

void VisualizzaSchema(MEMORY memory,int nr,int nc)
{
  int r,c;
  int i,j;

#ifdef DEBUG
  fprintf(stderr,"VisualizzaSchema - nr: %d\n",nr);
  fprintf(stderr,"VisualizzaSchema - nc: %d\n",nc);
#endif
  for (i=0,r=RIGA_INIZIALE-1;i<nr;r+=2,i++)
  {
    for (j=0,c=COLONNA_INIZIALE-2;j<nc;c+=4,j++)
    {
      TracciaRettangolo(r,c,r+2,c+4);
      if (memory[i][j] < 0)
        ScriveCarattereYX(r+1,c+2,' ' | A_REVERSE);	// la tessera e' COPERTA
      else if (memory[i][j] <= 26)
        ScriveCarattereYX(r+1,c+2,memory[i][j]+'A'-1);	// la tessera e' SCOPERTA
      else if (memory[i][j] <= 52)
        ScriveCarattereYX(r+1,c+2,memory[i][j]-26+'a'-1);	// la tessera e' SCOPERTA
      else if (memory[i][j] <= 62)
        ScriveCarattereYX(r+1,c+2,memory[i][j]-52+'0'-1);	// la tessera e' SCOPERTA
#ifdef DEBUG
      fprintf(stderr,"VisualizzaSchema - memory[%d][%d]: %d\n",i,j,memory[i][j]);
#endif
    }
  }
  ScriveYX(2*nr+2,0,"Righe: %d - Colonne: %d - Mosse: %d",nr,nc,mosse);
}

void NuovoGioco(MEMORY memory,int nr,int nc)
{
#ifdef DEBUG
  fprintf(stderr,"NuovoGioco - nr: %d\n",nr);
  fprintf(stderr,"NuovoGioco - nc: %d\n",nc);
#endif
  stato = 0;
  mosse = 0;
  mancanti = nr*nc;
  indicePrimo = 0;
  indiceSecondo = 0;
  GeneraSchema(memory,nr,nc);
  MischiaSchema(memory,nr,nc);
  VisualizzaSchema(memory,nr,nc);
}

void ControllaPosizioneSchema(MEMORY memory,int nr,int nc,int i,int j)
{
  int r,c;

#ifdef DEBUG
  fprintf(stderr,"ControllaPosizioneSchema - nr: %d\n",nr);
  fprintf(stderr,"ControllaPosizioneSchema - nc: %d\n",nc);
#endif
  LeggePosizioneCursore(r,c);
  if (memory[i][j] < 0)
  {
    memory[i][j] = -memory[i][j];
    VisualizzaSchema(memory,nr,nc);
    SpostaCursore(r,c);

    AggiornaSchermo();
    mancanti--;
    mosse++;
    if (stato == 0)
    {
      stato = 1;
      indicePrimo = i*NC+j;
#ifdef DEBUG
      fprintf(stderr,"ControllaPosizioneSchema - PRIMA SELEZIONE - memory[%d][%d]: %d\n",i,j,memory[i][j]);
#endif
    }
    else if (stato == 1)
    {
      stato = 0;
      indiceSecondo = i*NC+j;
#ifdef DEBUG
      fprintf(stderr,"ControllaPosizioneSchema - SECONDA SELEZIONE - memory[%d][%d]: %d\n",i,j,memory[i][j]);
#endif
      if (memory[i][j] != memory[indicePrimo/NC][indicePrimo%NC])
      {
	mancanti += 2;
	memory[i][j] = -memory[i][j];
	memory[indicePrimo/NC][indicePrimo%NC] = -memory[indicePrimo/NC][indicePrimo%NC];
        Ritardo(500);
        VisualizzaSchema(memory,nr,nc);
        AggiornaSchermo();
      }
      if (mancanti <= 0)
      {
        ScriveYX(2*nr+3,0,"HAI ");
        if (mosse <= (3*nr*nc)/2)
          Scrive("UN'OTTIMA MEMORIA!");
        else
          Scrive("UNA BUONA MEMORIA!");
        AggiornaSchermo();
      }
    }
  }
}

int main(int argc,char *argv[])
{
  int r,c;
  int rFinale,cFinale;
  int i,j;

  InizializzazioneNCurses();

  if (argc == 3)
  {
    if (sscanf(argv[1],"%d",&nr) != 1 || sscanf(argv[2],"%d",&nc) != 1)
    {
      nr = NR;
      nc = NC;
    }
    else if ((nr*nc)%2 != 0 || nr*nc>120 || nr > NR || nc > NC)
    {
      nr = NR;
      nc = NC;
    }
  }
  else
  {
    nr = NR;
    nc = NC;
  }
#ifdef DEBUG
  fprintf(stderr,"nr: %d\n",nr);
  fprintf(stderr,"nc: %d\n",nc);
#endif
  r = RIGA_INIZIALE;
  c = COLONNA_INIZIALE;
  rFinale = RIGA_INIZIALE+2*(nr-1);
  cFinale = COLONNA_INIZIALE+4*(nc-1);
  i = j = 0;
  NuovoGioco(memory,nr,nc);
  do
  {
    VisualizzaSchema(memory,nr,nc);
    SpostaCursore(r,c);
    AggiornaSchermo();
    carattere = LeggeCarattereDaTastiera();
    if (carattere == SU)
    {
      if (r > RIGA_INIZIALE)
      {
        r -= 2;
        i--;
      }
      else
      {
        r = rFinale;
        i = NR-1;
      }
    }
    else if (carattere == GIU)
    {
      if (r < rFinale)
      {
        r += 2;
        i++;
      }
      else
      {
        r = RIGA_INIZIALE;
        i = 0;
      }
    }
    else if (carattere == SINISTRA)
    {
      if (c > COLONNA_INIZIALE)
      {
        c -= 4;
        j--;
      }
      else
      {
        c = cFinale;
        j = NC-1;
      }
    }
    else if (carattere == DESTRA)
    {
      if (c < cFinale)
      {
        c += 4;
        j++;
      }
      else
      {
        c = COLONNA_INIZIALE;
        j = 0;
      }
    }
    else if (carattere == INVIO)
      ControllaPosizioneSchema(memory,nr,nc,i,j);
  }
  while (carattere != ESC && mancanti > 0) ; // attende la pressione del tasto ESC o la fine del gioco per uscire dal programma
  if (carattere != ESC)
    Ritardo(5000);
  ChiusuraNCurses();

  return 0;
}
